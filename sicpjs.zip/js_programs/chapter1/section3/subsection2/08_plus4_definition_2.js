const plus4 = x => x + 4;

plus4(3);
