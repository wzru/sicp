expmod(base, exp / 2, m)
