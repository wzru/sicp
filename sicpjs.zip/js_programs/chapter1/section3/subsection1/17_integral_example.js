function cube(x) {
    return x * x * x;
}
integral(cube, 0, 1, 0.01);
