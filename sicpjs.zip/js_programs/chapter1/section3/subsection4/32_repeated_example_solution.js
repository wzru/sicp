function square(x) {
    return x * x;
}
repeated(square, 2)(5); // 625
