n_fold_smooth(cube, 5)(4);
