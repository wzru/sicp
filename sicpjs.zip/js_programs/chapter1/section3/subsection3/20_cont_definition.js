// cont_frac to be written by student; see exercise 1.37
