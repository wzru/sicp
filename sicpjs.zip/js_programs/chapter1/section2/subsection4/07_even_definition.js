function is_even(n) {
    return n % 2 === 0;
}

is_even(7);
