function square(x) {
    return x * x;
}
square(square(3));

// expected: 81
