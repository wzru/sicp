const b = a + 1;
a + b + a * b;
