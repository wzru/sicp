2 * 4 + (4 - 6);

// expected: 6
