const b = a + 1;
(a > b
 ? a
 : a < b
   ? b
   : -1)
*
(a + 1);
