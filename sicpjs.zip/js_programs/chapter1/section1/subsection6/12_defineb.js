const a = 3;
const b = a + 1;
