function greater_or_equal(x, y) {
    return x > y || x === y;
}

greater_or_equal(7, 4);
