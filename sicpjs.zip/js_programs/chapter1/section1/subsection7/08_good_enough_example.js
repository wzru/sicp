good_enough(1.41, 2);
