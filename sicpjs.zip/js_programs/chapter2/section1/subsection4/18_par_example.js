print_interval(par1(pair(4,6), pair(7,8)))
+
print_interval(par2(pair(4,6), pair(7,8)));
