function count_leaves(t) {
    return accumulate(??, ??, map(??, ??));
}

count_leaves(pair(list(1, 2), list(3, 4)));
