length(list_fib_squares(10));
