length(prime_sum_pairs(6));
