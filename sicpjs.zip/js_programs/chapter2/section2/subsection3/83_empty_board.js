const empty_board = null;
