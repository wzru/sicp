function reverse(sequence) {
    return fold_right((x, y) => ??, null, sequence);
}

reverse(list(1, 4, 9, 16, 25));
