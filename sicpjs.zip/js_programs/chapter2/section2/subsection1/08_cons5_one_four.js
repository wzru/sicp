const one_through_four = list(1, 2, 3, 4);
pair(5, one_through_four);

// expected: [ 5, [ 1, [ 2, [ 3, [ 4, null ] ] ] ] ]
