function square_list(items) {
    return is_null(items) 
           ? null
           : pair(??, ??);
}

square_list(list(1, 2, 3, 4));
