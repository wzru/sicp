function square_list(items) {
   return map(??, ??);
}

square_list(list(1, 2, 3, 4));
