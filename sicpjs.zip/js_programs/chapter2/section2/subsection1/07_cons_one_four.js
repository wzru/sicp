const one_through_four = list(1, 2, 3, 4);
pair(10, one_through_four);

// expected: [ 10, [ 1, [ 2, [ 3, [ 4, null ] ] ] ] ]
