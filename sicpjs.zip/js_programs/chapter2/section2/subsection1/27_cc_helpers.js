// first_denomination, except_first_denomination
// and no_more to be given by student
