const heart2 = beside(heart, flip_vert(heart));

show(heart2);
