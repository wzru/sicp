show(square_limit(heart, 5));
