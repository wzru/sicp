const my_vector_1 = make_vect(1.0, 2.0);
const my_vector_2 = make_vect(3.0, 4.0);
add_vect(my_vector_1, my_vector_2);
