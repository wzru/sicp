tail(subsets(list(1, 2)));
