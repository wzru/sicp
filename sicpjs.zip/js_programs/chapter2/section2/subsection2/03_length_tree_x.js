const x = pair(pair(1, pair(2,null)), pair(3, pair(4,null)));
length(x);

// expected: 3
