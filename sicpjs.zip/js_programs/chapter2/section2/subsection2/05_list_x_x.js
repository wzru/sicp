const x = pair(pair(1, pair(2,null)), pair(3, pair(4,null)));
length(head(tail(list(x, x))));

// expected: 3
