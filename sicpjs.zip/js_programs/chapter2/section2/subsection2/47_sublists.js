function subsets(s) {
    if (is_null(s)) {
        return list(null);
    } else {
        const rest = subsets(tail(s));
        return append(rest, map(x => pair(head(s), x), rest));
    }
}

tail(subsets(list(1, 2)));

// expected: [ [ 2, null ], [ [ 1, null ], [ [ 1, [ 2, null ] ], null ] ] ]
