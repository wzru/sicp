function make_mobile(left, right) {
   return pair(left, right);
}
function make_branch(length, structure) {
   return pair(length, structure);
}
