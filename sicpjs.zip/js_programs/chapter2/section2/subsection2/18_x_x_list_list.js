const x = list(list(1, 2), list(3, 4));
x;

// expected: [ [ 1, [ 2, null ] ], [ [ 3, [ 4, null ] ], null ] ]
