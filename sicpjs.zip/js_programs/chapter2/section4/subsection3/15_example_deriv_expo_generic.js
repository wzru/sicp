head(tail(head(tail(tail(deriv(list("**", "x", 4), "x"))))));
