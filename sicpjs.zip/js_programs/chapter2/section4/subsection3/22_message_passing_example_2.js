const my_complex_number = 
    make_from_mag_ang(3.0, 0.7);

const result = 
    add_complex(my_complex_number,
                my_complex_number);

real_part(result);
