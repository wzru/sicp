// chapter=4 
const c = make_complex_from_real_imag(4, 3);
const n = make_javascript_number(7);

add(c, n);
