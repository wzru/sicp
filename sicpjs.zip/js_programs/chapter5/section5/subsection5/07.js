assign("val", op("lookup_variable_value"), constant("a"), reg("env")),
assign("val", op("+"), reg("val"), constant(1)),
