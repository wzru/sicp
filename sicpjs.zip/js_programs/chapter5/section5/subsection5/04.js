assign("val", constant(1)),
go_to(reg("continue")),
