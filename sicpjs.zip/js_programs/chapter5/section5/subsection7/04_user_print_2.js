function user_print(prompt_string, object) {
   function to_string(object) {	
       return is_compound_function(object)
              ? "<compound-function>"
              : is_compiled_function(object)
              ? "<compiled-function>"
              : is_primitive_function(object)
	      ? "<primitive-function>"
	      : is_pair(object)
	      ? "[" + to_string(head(object)) + ", "
	            + to_string(tail(object)) + "]"
	      : stringify(object);
    }
    display("----------------------------",
            prompt_string + "\n" + to_string(object) + "\n");
}
