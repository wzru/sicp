function user_print(prompt_string, object) {
    if (is_compound_function(object)) {
        display("<compound_function>",
                prompt_string);    
    } else if (is_compiled_function(object)) {
        display("<compiled-function>",
                prompt_string);
    } else {
        display(object,
                prompt_string);
    }
}
