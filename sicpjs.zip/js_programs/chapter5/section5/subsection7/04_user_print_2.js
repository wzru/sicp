function user_print(object) {
    if (is_compound_function(object)) {
        display(list(
            "compound_function",
            function_parameters(object),
            function_body(object),
            "<compiler-env>"));
    } else if (is_compiled_function(object)) {
        display("<compiled-function>");
    } else {
        display(object);
    }
}
