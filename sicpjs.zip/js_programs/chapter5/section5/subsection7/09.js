compile_and_run(
    parse(
        "function factorial(n) {         \
             return n === 1              \
                 ? 1                     \
                 : n * factorial(n - 1); \
         }"));
