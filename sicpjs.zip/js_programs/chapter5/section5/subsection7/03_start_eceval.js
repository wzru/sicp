function start_eceval() {
    set_register_contents(eceval, "flag", false);
    return start(eceval);
}
