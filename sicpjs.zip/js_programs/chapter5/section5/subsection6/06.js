(+ * a b x y) => (a * x) + (b * y)
