let x = 3;
let y = 4;
(a, b, c, d, e) => {
    let y = a * b * x;
    let z = c + d + x;
    return x * y * z;
}
