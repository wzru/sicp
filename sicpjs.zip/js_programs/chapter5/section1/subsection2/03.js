function square(x) {
    return x * x;
}

function average(x,y) {
    return (x + y) / 2;
}

function sqrt(x) {
    function good_enough(guess) {
        return math_abs(square(guess) - x) < 0.001;
    }
    function improve(guess) {
        return average(guess, x / guess);
    }
    function sqrt_iter(guess) {
        return good_enough(guess)
            ? guess
            : sqrt_iter(improve(guess));
    }
    return  sqrt_iter(1.0);
}

display(sqrt(4));   // Should display close to 2
display(sqrt(9));   // Should display close to 3
display(sqrt(100)); // Should display close to 10
// Change 0.001 above to tune precision
