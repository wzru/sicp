expt(3, 4);

// expected: 81
