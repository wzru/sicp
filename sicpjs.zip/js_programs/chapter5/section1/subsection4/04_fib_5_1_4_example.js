fib(6);

// expected: 8
