gcd(20, 12);

// expected: 4
