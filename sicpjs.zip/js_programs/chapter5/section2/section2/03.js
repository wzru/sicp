set_register_contents(gcd_machine, "b", 40);
"done"
