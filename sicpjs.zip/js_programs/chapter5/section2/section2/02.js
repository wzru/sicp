set_register_contents(gcd_machine, "a", 206); 
"done"
