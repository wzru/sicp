"start"
    go_to(label(here)),
    "here",
    assign("a", list(const(3))),
    go_to(label(there)),
    "here",
    assign("a", list(const(4))),
    go_to(label(there)),
    "there",
