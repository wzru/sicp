function make_label_entry(label_name, insts) {
    return pair(label_name, insts);
}
