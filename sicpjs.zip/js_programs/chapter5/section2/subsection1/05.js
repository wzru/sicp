function pop(stack) {
    return stack("pop");
}

function push(stack, value) {
    return stack("push")(value);
}
