function make_machine(register_names, ops, controller_text) {
    const machine = make_new_machine();

    for_each(register_name => machine("allocate_register")(register_name), register_names);
    machine("install_operations")(ops);
    machine("install_instruction_sequence")(assemble(controller_text, machine));

    return machine;
}
