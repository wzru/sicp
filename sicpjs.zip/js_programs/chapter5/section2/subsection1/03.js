function get_contents(register) {
    return register("get");
}

function set_contents(register, value) {
    return register("set")(value);
}
