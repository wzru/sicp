function get_register(machine, reg_name) {
    return machine("get_register")(reg_name);
}
