set_breakpoint(gcd_machine, "test-b", 4);
