"print_result",
    perform(op("print_stack_statistics")), // added instruction
    perform(op("announce_output"), constant("/// EC-Eval value:")),
    /* ... same as before ... */
