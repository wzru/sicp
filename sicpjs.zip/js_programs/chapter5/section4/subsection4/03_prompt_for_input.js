function prompt_for_input(p) {
    const string = prompt(p);
    return is_null(string) ? null : parse(string);
}
