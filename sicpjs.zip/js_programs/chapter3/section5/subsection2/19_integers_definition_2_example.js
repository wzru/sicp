stream_ref(integers, 50);
