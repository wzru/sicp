// mul_streams to be written by students
const factorials = pair(1, () => mul_streams(??, ??));
