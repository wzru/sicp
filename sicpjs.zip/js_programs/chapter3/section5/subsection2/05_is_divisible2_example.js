is_divisible(42, 7);
