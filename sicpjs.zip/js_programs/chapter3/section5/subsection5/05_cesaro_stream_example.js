stream_ref(cesaro_stream, 42);
