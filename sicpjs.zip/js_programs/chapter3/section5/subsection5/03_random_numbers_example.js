stream_ref(random_numbers, 4);
