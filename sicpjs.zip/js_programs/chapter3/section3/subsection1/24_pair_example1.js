const x = list("a", "b");
const z1 = pair(x, x);
