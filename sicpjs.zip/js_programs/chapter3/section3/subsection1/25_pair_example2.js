const z2 = pair(list("a", "b"), list("a", "b"));
