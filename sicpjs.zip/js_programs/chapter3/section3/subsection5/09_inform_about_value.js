function inform_about_value(constraint) {
    return constraint("I_have_a_value");
}

function inform_about_no_value(constraint) {
    return constraint("I_lost_my_value");
}
