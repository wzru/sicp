// make_accumulator to be written by students
const a = make_accumulator(5);
a(10);
