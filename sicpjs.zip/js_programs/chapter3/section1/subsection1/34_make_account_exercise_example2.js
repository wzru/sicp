// make_account function to be written by students
const acc = make_account(100, "secret password");
(acc("secret password", "withdraw"))(40);
(acc("some other password", "deposit"))(40);
