const random_init = 123456789;
