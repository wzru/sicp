// operation_table, put and get
// from chapter 3 (section 3.3.3)
function assoc(key, records) {
    return is_null(records)
           ? undefined
           : equal(key, head(head(records)))
             ? head(records)
             : assoc(key, tail(records));
}
function make_table() {
    const local_table = list("*table*");
    function lookup(key_1, key_2) {
        const subtable = assoc(key_1, tail(local_table));
        if (subtable === undefined) {
            return undefined;
        } else {
            const record = assoc(key_2, tail(subtable));
            if (record === undefined) {
                return undefined;
            } else {
                return tail(record);
            }
        }
    }
    function insert(key_1, key_2, value) {
        const subtable = assoc(key_1, tail(local_table));
        if (subtable === undefined) {
            set_tail(local_table,
                     pair(list(key_1, pair(key_2, value)),
                          tail(local_table)));
        } else {
            const record = assoc(key_2, tail(subtable));
            if (record === undefined) {
      	        set_tail(subtable,
	                       pair(pair(key_2, value),
                              tail(subtable)));
	    } else {
                set_tail(record, value);
            }
        }
    }
    function dispatch(m) {
        return m === "lookup"
               ? lookup
               : m === "insert"
                 ? insert
                 : "undefined operation -- table";
    }
    return dispatch;
}
const operation_table = make_table();
const get = operation_table("lookup");
const put = operation_table("insert");
function stream_append_delayed(s1, delayed_s2) {
    return is_null(s1)
        ? delayed_s2()
        : pair(head(s1),
               () => stream_append_delayed(stream_tail(s1),
                                           delayed_s2));
}
function interleave_delayed(s1, delayed_s2) {
    return is_null(s1)
        ? delayed_s2()
        : pair(head(s1),
               () => interleave_delayed(delayed_s2(),
                         () => stream_tail(s1)));
}
function stream_flatmap(fun, s) {
    return flatten_stream(stream_map(fun, s));
}
function flatten_stream(stream) {
    return is_null(stream)
        ? null
        : interleave_delayed(head(stream),
              () => flatten_stream(stream_tail(stream)));
}
function make_binding(variable, value) {
    return pair(variable, value);
}
function binding_variable(binding) {
    return head(binding);
}
function binding_value(binding) {
    return tail(binding);
}
function binding_in_frame(variable, frame) {
    return assoc(variable, frame);
}
function extend(variable, value, frame) {
    return pair(make_binding(variable, value), frame);
}
function extend_if_consistent(variable, dat, frame) {
    const binding = binding_in_frame(variable, frame);
    return binding === undefined
        ? extend(variable, dat, frame)
        : pattern_match(binding_value(binding), dat, frame);
}
// functions from SICP JS 4.1.2
function is_self_evaluating(stmt) {
    return is_number(stmt)  ||
           is_string(stmt)  ||
           is_boolean(stmt) ||
           is_null(stmt);
}
function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}
function is_name(stmt) {
    return is_tagged_list(stmt, "name");
}
function symbol_of_name(stmt) {
    return head(tail(stmt));
}
function is_assignment(stmt) {
   return is_tagged_list(stmt, "assignment");
}
function assignment_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function assignment_value(stmt) {
   return head(tail(tail(stmt)));
}
function is_constant_declaration(stmt) {
   return is_tagged_list(stmt, "constant_declaration");
}
function constant_declaration_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function constant_declaration_value(stmt) {
   return head(tail(tail(stmt)));
}
function is_variable_declaration(stmt) {
   return is_tagged_list(stmt, "variable_declaration");
}
function variable_declaration_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function variable_declaration_value(stmt) {
   return head(tail(tail(stmt)));
}
// FIXME: replace "function_definition" with "lambda"
// after this issue is handled:
// https://github.com/source-academy/js-slang/issues/634
function is_lambda(stmt) {
   return is_tagged_list(stmt, "function_definition");
}
function lambda_parameters(stmt) {
   return map(symbol_of_name, head(tail(stmt)));
}
function lambda_body(stmt) {
   return head(tail(tail(stmt)));
}
function is_return(stmt) {
   return is_tagged_list(stmt, "return_statement");
}
function return_expression(stmt) {
   return head(tail(stmt));
}
function is_conditional_expression(stmt) {
   return is_tagged_list(stmt, 
                "conditional_expression");
}
function cond_expr_pred(stmt) {
   return list_ref(stmt, 1);
}
function cond_expr_cons(stmt) {
   return list_ref(stmt, 2);
}
function cond_expr_alt(stmt) {
   return list_ref(stmt, 3);
}
function is_sequence(stmt) {
   return is_tagged_list(stmt, "sequence");
}
function make_sequence(stmts) {
   return list("sequence", stmts);
}
function sequence_statements(stmt) {   
   return head(tail(stmt));
}
function first_statement(stmts) {
   return head(stmts);
}
function rest_statements(stmts) {
   return tail(stmts);
}
function is_empty_sequence(stmts) {
   return is_null(stmts);
}
function is_last_statement(stmts) {
   return is_null(tail(stmts));
}
function is_block(stmt) {
    return is_tagged_list(stmt, "block");
}
function make_block(stmt) {
   return list("block", stmt);
}
function block_body(stmt) {
    return head(tail(stmt));
}
function is_application(stmt) {
   return is_tagged_list(stmt, "application");
}
function function_expression(stmt) {
   return head(tail(stmt));
}
function args(stmt) {
   return head(tail(tail(stmt)));
}
function no_args(ops) {
   return is_null(ops);
}
function first_arg(ops) {
   return head(ops);
}
function rest_args(ops) {
   return tail(ops);
}

function is_var(exp) {
    return is_tagged_list(exp, "?");
}
function pattern_match(pat, dat, frame) {
    return frame === "failed" 
        ? "failed"
        : equal(pat, dat) 
        ? frame   
        : is_var(pat) 
        ? extend_if_consistent(pat, dat, frame)
        : is_pair(pat) && is_pair(dat)
        ? pattern_match(tail(pat),
                        tail(dat),
                        pattern_match(head(pat),
                                      head(dat),
                                      frame))
        : "failed";
}
function singleton_stream(x) {
    return pair(x, () => null);
}
function check_an_assertion(assertion, query_pat, query_frame) {
    const match_result = pattern_match(query_pat, assertion, 
                                       query_frame);
    return match_result === "failed"
        ? null
        : singleton_stream(match_result);
}
function use_index(pat) {
    return is_string(head(pat));
}
function get_stream(key1, key2) {
    const s = get(key1, key2);
    return s === undefined ? null : s;
}
function index_key_of(pat) {
    const key = head(pat);
    return is_var(key) ? "?" : key;
}
let THE_ASSERTIONS = null;

function fetch_assertions(pattern, frame) {
    return use_index(pattern)
        ? get_indexed_assertions(pattern)
        : get_all_assertions;
}
function get_all_assertions() {
    return THE_ASSERTIONS;
}
function get_indexed_assertions(pattern) {
    return get_stream(index_key_of(pattern), "assertion-stream");
}
function find_assertions(pattern, frame) {
    return stream_flatmap(
              datum =>
                 check_an_assertion(datum, pattern, frame),
              fetch_assertions(pattern, frame));
}
let rule_counter = 0;

function new_rule_application_id() {
    rule_counter = rule_counter + 1;
    return rule_counter;
}
function make_new_variable(variable, rule_application_id) {
    return pair("?", pair(rule_application_id, tail(variable)));
}
function rename_variables_in(rule) {
    const rule_application_id = new_rule_application_id();
    function tree_walk(exp) {
        return is_var(exp) 
            ? make_new_variable(exp, rule_application_id)
            : is_pair(exp)
            ? pair(tree_walk(head(exp)),
                   tree_walk(tail(exp)))
            : exp;
    }
    return tree_walk(rule);
}
function depends_on(exp, variable, frame) {
    function tree_walk(e) {
        if (is_var(e)) {
            if (equal(variable, e)) {
                return true;
            } else {
                const b = binding_in_frame(e, frame);
                return b === undefined
                    ? false
                    : tree_walk(binding_value(b));
            }
	} else {
            return is_pair(e) 
                ? tree_walk(head(e)) || tree_walk(tail(e))
                : false;
        }
    }
    return tree_walk(exp);
}
function extend_if_possible(variable, val, frame) {
    const binding = binding_in_frame(variable, frame);
    if (binding !== undefined) {
        return unify_match(binding_value(binding), 
                            val, frame); 
    } else if (is_var(val)) {                      // ***
        const binding = binding_in_frame(val, frame);
        return binding !== undefined
            ? unify_match(variable,
                          binding_value(binding),
			  frame)
            : extend(variable, val, frame);
    } else if (depends_on(val, variable, frame)) { // ***
        return "failed";
    } else {
        return extend(variable, val, frame);
    }
}
function unify_match(p1, p2, frame) {
    return frame === "failed"
        ? "failed"
        : equal(p1, p2)
        ? frame
        : is_var(p1) 
        ? extend_if_possible(p1, p2, frame)
        : is_var(p2) 
        ? extend_if_possible(p2, p1, frame)  // ***
        : is_pair(p1) && is_pair(p2)
        ? unify_match(tail(p1),
                      tail(p2),
                      unify_match(head(p1),
                                  head(p2),
                                  frame))
        : "failed";
}
function is_rule(statement) {
    return is_tagged_list(statement, "rule");
}
function conclusion(rule) {
    return head(tail(rule));
}
function rule_body(rule) {
    return is_null(tail(tail(rule)))
        ? list("always_true")
        : head(tail(tail(rule)));
}
function apply_a_rule(rule, query_pattern, query_frame) {
    const clean_rule = rename_variables_in(rule);
    const unify_result = 
             unify_match(query_pattern,
                         conclusion(clean_rule),
                         query_frame);
    return unify_result === "failed"
        ? null
        : evaluate_query(rule_body(clean_rule),
                singleton_stream(unify_result));
}
let THE_RULES = null;

function fetch_rules(pattern, frame) {
    return use_index(pattern)
        ? get_indexed_rules(pattern)
        : get_all_rules();
}
function get_all_rules() {
    return THE_RULES;
}
function get_indexed_rules(pattern) {
    return stream_append(
              get_stream(index_key_of(pattern),
                         "rule-stream"),
              get_stream("?", "rule-stream"));
}
function apply_rules(pattern, frame) {
    return stream_flatmap(
              rule => 
                 apply_a_rule(rule, pattern, frame),
              fetch_rules(pattern, frame));
}
function simple_query(query_pattern, frame_stream) {
    return stream_flatmap(
        frame => 
            stream_append_delayed(find_assertions(query_pattern, frame),
                                  () => apply_rules(query_pattern, frame)),
        frame_stream);
}
function type(exp) {
    return is_pair(exp)
        ? head(exp)
        : error(exp, "Unknown expression in type:");
}
function contents(exp) {
    return is_pair(exp)
        ? tail(exp)
        : error(exp, "Unknown expression in contents:");
}
function evaluate_query(query, frame_stream) {
    const qfun = get(type(query), "evaluate_query");
    return qfun === undefined
        ? simple_query(query, frame_stream)
        : qfun(contents(query), frame_stream);
}
