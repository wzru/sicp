function is_empty_conjunction(exps) {
    return is_null(exps);
}
function first_conjunct(exps) {
    return head(exps);
}
function rest_conjuncts(exps) {
    return tail(exps);
}
function is_empty_disjunction(exps) {
    return is_null(exps);
}
function first_disjunct(exps) {
    return head(exps);
}
function rest_disjuncts(exps) {
    return tail(exps);
}
function negated_query(exps) {
    return head(exps);
}
function predicate(exps) {
    return head(exps);
}
function argmnts(exps) {
    return tail(exps);
}
