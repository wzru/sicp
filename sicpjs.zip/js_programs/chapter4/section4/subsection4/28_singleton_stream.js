function singleton_stream(x) {
    return pair(x, () => null);
}
