process_query('assert(son("Adam", "Cain"))');
process_query('son("Adam", x)');
