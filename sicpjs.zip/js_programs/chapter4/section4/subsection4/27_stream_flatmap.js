function stream_append_delayed(s1, delayed_s2) {
    return is_null(s1)
        ? delayed_s2()
        : pair(head(s1),
               () => stream_append_delayed(stream_tail(s1),
                                           delayed_s2));
}
function interleave_delayed(s1, delayed_s2) {
    return is_null(s1)
        ? delayed_s2()
        : pair(head(s1),
               () => interleave_delayed(delayed_s2(),
                         () => stream_tail(s1)));
}
function stream_flatmap(fun, s) {
    return flatten_stream(stream_map(fun, s));
}
function flatten_stream(stream) {
    return is_null(stream)
        ? null
        : interleave_delayed(head(stream),
              () => flatten_stream(stream_tail(stream)));
}
