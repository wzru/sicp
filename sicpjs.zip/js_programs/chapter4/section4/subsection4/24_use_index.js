function use_index(pat) {
    return is_string(head(pat));
}
