job(x, list("computer", "programmer"));
