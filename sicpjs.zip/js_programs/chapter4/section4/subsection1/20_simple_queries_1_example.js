// functions from SICP JS 4.1.1
function evaluate(stmt, env) {
   return is_self_evaluating(stmt)
          ?  stmt
          : is_name(stmt)
          ? lookup_symbol_value(symbol_of_name(stmt), env)
          : is_constant_declaration(stmt)
          ? eval_constant_declaration(stmt, env)
          : is_variable_declaration(stmt)
          ? eval_variable_declaration(stmt, env)
          : is_assignment(stmt)
          ? eval_assignment(stmt, env)
          : is_conditional_expression(stmt)
          ? eval_conditional_expression(stmt, env)
          : is_lambda(stmt)
          ? make_function(lambda_parameters(stmt),
                          lambda_body(stmt),
                          env)
          : is_sequence(stmt)
          ? eval_sequence(sequence_statements(stmt), env)
          : is_block(stmt)
          ? eval_block(stmt, env)
          : is_return(stmt)
          ? eval_return(stmt, env)
          : is_application(stmt)
          ? apply(evaluate(function_expression(stmt), env),
                  list_of_values(args(stmt), env))
          : error(stmt, "Unknown syntax in evaluate:");
}
function apply(fun, args) {
   if (is_primitive_function(fun)) {
      return apply_primitive_function(fun, args);
   } else if (is_compound_function(fun)) {
      const result = evaluate(function_body(fun),
                         extend_environment(
                             function_parameters(fun),
                             args,
                             function_environment(fun)));
      return is_return_value(result)
             ? return_value_content(result)
             : undefined;
   } else {
      error(fun, "Unknown function type in apply");
   }
}
function list_of_values(exps, env) {
     return no_args(exps)
         ? null
         : pair(evaluate(first_arg(exps), env),
                list_of_values(rest_args(exps), env));
}
function eval_conditional_expression(stmt, env) {
    return is_true(evaluate(cond_expr_pred(stmt), env))
           ? evaluate(cond_expr_cons(stmt), env)
           : evaluate(cond_expr_alt(stmt), env);
}
function eval_sequence(stmts, env) {
    if (is_empty_sequence(stmts)) {
        return undefined;
    } else if (is_last_statement(stmts)) {
            return evaluate(first_statement(stmts),env);
    } else {
        const first_stmt_value = 
            evaluate(first_statement(stmts),env);
        if (is_return_value(first_stmt_value)) {
            return first_stmt_value;
        } else {
            return eval_sequence(
                rest_statements(stmts),env);
        }
    }
}
const unassigned = () => null;
function list_of_unassigned(names) {
    return is_null(names)
        ? null
        : pair(unassigned, list_of_unassigned(tail(names)));	    
}
function scan_out_declarations(stmt) {
    if (is_sequence(stmt)) {
        const stmts = sequence_statements(stmt);
        return is_empty_sequence(stmts)
            ? null
            : append(scan_out_declarations(first_statement(stmts)),
                     scan_out_declarations(make_sequence(
                                   rest_statements(stmts))));
    } else {
       return is_constant_declaration(stmt)
              ? list(constant_declaration_symbol(stmt))
              : is_variable_declaration(stmt)
                ? list(variable_declaration_symbol(stmt))
                : null;
    }
}
function eval_block(stmt, env) {
    const body = block_body(stmt);
    const locals = scan_out_declarations(body);
    const unassigneds = list_of_unassigned(locals);
    return evaluate(body,
                extend_environment(locals, unassigneds, env));
}
function eval_return(stmt, env) {
    return make_return_value(
               evaluate(return_expression(stmt),
                        env));
}
function eval_assignment(stmt, env) {
    const value = evaluate(assignment_value(stmt), env);
    assign_symbol_value(assignment_symbol(stmt), value, env);
    return value;
}
function eval_variable_declaration(stmt, env) {
    assign_symbol_value(variable_declaration_symbol(stmt),
        evaluate(variable_declaration_value(stmt), env),
        env);
}   
function eval_constant_declaration(stmt, env) {
    assign_symbol_value(constant_declaration_symbol(stmt),
        evaluate(constant_declaration_value(stmt), env),
        env);
}

// functions from SICP JS 4.1.2
function is_self_evaluating(stmt) {
    return is_number(stmt)  ||
           is_string(stmt)  ||
           is_boolean(stmt) ||
           is_null(stmt);
}
function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}
function is_name(stmt) {
    return is_tagged_list(stmt, "name");
}
function symbol_of_name(stmt) {
    return head(tail(stmt));
}
function is_assignment(stmt) {
   return is_tagged_list(stmt, "assignment");
}
function assignment_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function assignment_value(stmt) {
   return head(tail(tail(stmt)));
}
function is_constant_declaration(stmt) {
   return is_tagged_list(stmt, "constant_declaration");
}
function constant_declaration_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function constant_declaration_value(stmt) {
   return head(tail(tail(stmt)));
}
function is_variable_declaration(stmt) {
   return is_tagged_list(stmt, "variable_declaration");
}
function variable_declaration_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function variable_declaration_value(stmt) {
   return head(tail(tail(stmt)));
}
// FIXME: replace "function_definition" with "lambda"
// after this issue is handled:
// https://github.com/source-academy/js-slang/issues/634
// FIXME: remove the block from lambda_body once the
// parser wraps the body in a block whenever needed.
function is_lambda(stmt) {
   return is_tagged_list(stmt, "function_definition");
}
function lambda_parameters(stmt) {
   return map(symbol_of_name, head(tail(stmt)));
}
function lambda_body(stmt) {
   return make_block(head(tail(tail(stmt))));
}
function is_return(stmt) {
   return is_tagged_list(stmt, "return_statement");
}
function return_expression(stmt) {
   return head(tail(stmt));
}
function is_conditional_expression(stmt) {
   return is_tagged_list(stmt, 
                "conditional_expression");
}
function cond_expr_pred(stmt) {
   return list_ref(stmt, 1);
}
function cond_expr_cons(stmt) {
   return list_ref(stmt, 2);
}
function cond_expr_alt(stmt) {
   return list_ref(stmt, 3);
}
function is_sequence(stmt) {
   return is_tagged_list(stmt, "sequence");
}
function make_sequence(stmts) {
   return list("sequence", stmts);
}
function sequence_statements(stmt) {   
   return head(tail(stmt));
}
function first_statement(stmts) {
   return head(stmts);
}
function rest_statements(stmts) {
   return tail(stmts);
}
function is_empty_sequence(stmts) {
   return is_null(stmts);
}
function is_last_statement(stmts) {
   return is_null(tail(stmts));
}
function is_block(stmt) {
    return is_tagged_list(stmt, "block");
}
function make_block(stmt) {
   return list("block", stmt);
}
function block_body(stmt) {
    return head(tail(stmt));
}
function is_application(stmt) {
   return is_tagged_list(stmt, "application");
}
function function_expression(stmt) {
   return head(tail(stmt));
}
function args(stmt) {
   return head(tail(tail(stmt)));
}
function no_args(ops) {
   return is_null(ops);
}
function first_arg(ops) {
   return head(ops);
}
function rest_args(ops) {
   return tail(ops);
}

// functions from SICP JS 4.1.3
function is_true(x) {
    return x === true;
}
function make_function(parameters, body, env) {
    return list("compound_function",
                parameters, body, env);
}
function is_compound_function(f) {
    return is_tagged_list(f, "compound_function");
}
function function_parameters(f) {
    return list_ref(f, 1);
}
function function_body(f) {
    return list_ref(f, 2);
}
function function_environment(f) {
    return list_ref(f, 3);
}
function make_return_value(content) {
    return list("return_value", content);
}
function is_return_value(value) {
    return is_tagged_list(value, "return_value");
}
function return_value_content(value) {
    return head(tail(value));
}
function enclosing_environment(env) {
    return tail(env);
}
function first_frame(env) {
    return head(env);
}
function enclose_by(frame, env) {    
    return pair(frame, env);
}
const the_empty_environment = null;
function make_frame(symbols, values) {
    return pair(symbols, values);
}
function frame_symbols(frame) {    
    return head(frame);
}
function frame_values(frame) {    
    return tail(frame);
}
function extend_environment(symbols, vals, base_env) {
    return length(symbols) === length(vals)
           ? pair(make_frame(symbols, vals), base_env)
           : length(symbols) < length(vals)
             ? error("Too many arguments supplied: " + 
                     stringify(symbols) + ", " + 
                     stringify(vals))
             : error("Too few arguments supplied: " + 
                     stringify(symbols) + ", " + 
                     stringify(vals));
}
function lookup_symbol_value(symbol, env) {
    function env_loop(env) {
        function scan(symbols, vals) {
            return is_null(symbols)
                   ? env_loop(
                       enclosing_environment(env))
                   : symbol === head(symbols)
                     ? head(vals)
                     : scan(tail(symbols), tail(vals));
        }
        if (env === the_empty_environment) {
            error(symbol, "Unbound symbol: ");
        } else {
            const frame = first_frame(env);
            return scan(frame_symbols(frame),
                        frame_values(frame));
        }
    }
    return env_loop(env);
}
function assign_symbol_value(symbol, val, env) {
    function env_loop(env) {
        function scan(symbols, vals) {
            return is_null(symbols)
                ? env_loop(
                    enclosing_environment(env))
                : symbol === head(symbols)
                  ? set_head(vals, val)
                  : scan(tail(symbols), tail(vals));
        } 
        if (env === the_empty_environment) {
            error(symbol, "Unbound symbol in assignment:");
        } else {
            const frame = first_frame(env);
            return scan(frame_symbols(frame),
                        frame_values(frame));
        }
    }
    return env_loop(env);
}

// functions from SICP JS 4.1.4
function is_primitive_function(fun) {
   return is_tagged_list(fun, "primitive");
}
function primitive_implementation(fun) {
   return head(tail(fun));
}
const primitive_functions = list(
       list("head",    head             ),
       list("tail",    tail             ),
       list("pair",    pair             ),
       list("list",    list             ),
       list("is_null", is_null          ),
       list("display", display          ),
       list("error",   error            ),
       list("math_abs",math_abs         ),
       list("+",       (x, y) => x + y  ),
       list("-",       (x, y) => x - y  ),
       list("*",       (x, y) => x * y  ),
       list("/",       (x, y) => x / y  ),
       list("%",       (x, y) => x % y  ),
       list("===",     (x, y) => x === y),
       list("!==",     (x, y) => x !== y),
       list("<",       (x, y) => x <   y),
       list("<=",      (x, y) => x <=  y),
       list(">",       (x, y) => x >   y),
       list(">=",      (x, y) => x >=  y),
       list("!",        x     =>   !   x)
       );
const primitive_function_symbols =
        map(head, primitive_functions);
const primitive_function_objects =
        map(fun => list("primitive", head(tail(fun))),
            primitive_functions);
const primitive_constants = list(list("undefined", undefined),
                                 list("Infinity",  Infinity),
                                 list("math_PI",   math_PI),
                                 list("math_E",    math_E),
                                 list("NaN",       NaN)
                                );
const primitive_constant_symbols =
        map(f => head(f), primitive_constants);
const primitive_constant_values =
        map(f => head(tail(f)), primitive_constants);
function apply_primitive_function(fun, arg_list) {
    return apply_in_underlying_javascript(
                primitive_implementation(fun),
                arg_list);     
}
function setup_environment() {
    return extend_environment(
               append(primitive_function_symbols, 
                      primitive_constant_symbols),
               append(primitive_function_objects, 
                      primitive_constant_values),
               the_empty_environment);
}
const the_global_environment = setup_environment();

// functions from SICP JS 4.4.4
function contract_question_mark(variable) {
    return is_number(head(tail(variable)))
        ? head(tail(tail(variable))) + "_" + stringify(head(tail(variable)))
        : head(tail(variable));
}
function comma_separated(strings) {
    return accumulate((s, acc) => s + (acc === "" ? "" : ", " + acc),
                      "", strings);
}
function pretty(string, args, arg_pretty) {	
    return string + "(" + comma_separated(map(arg_pretty, args)) + ")";
}
function pretty_term(arg) {
    return is_null(arg)
        ? "null"
        : is_list(arg) &&
	  (is_null(tail(arg)) || head(tail(arg)) !== "?")
        ? (head(arg) === "?"
           ? contract_question_mark(arg)
           : (is_application(arg) &&
	      is_name(function_expression(arg)))
	   ? "(" + pretty_term(head(args(arg))) + 
	     " " + symbol_of_name(function_expression(arg)) + 
             " " + pretty_term(head(tail(args(arg)))) +
	     ")"
	   : pretty("list", arg, pretty_term))
        : is_pair(arg)
        ? pretty("pair", list(head(arg), tail(arg)), pretty_term)
	: is_string(arg)
        ? "'" + arg + "'"
	: stringify(arg);
}
function pretty_query(query) {
    return is_null(member(head(query),
                          list("and", "or", "not", "assert", "rule")))
	? pretty(head(query), tail(query), pretty_term)
        : pretty(head(query), tail(query), pretty_query);
}
function javascript_value_process(exp) {
    return is_application(exp)
        ? list("application", function_expression(exp),
               map(javascript_value_process, args(exp)))
        : is_name(exp)
        ? list("?", symbol_of_name(exp))
        : exp;
}
function query_syntax_process(exp) {
    if (is_application(exp)) {
      const function_symbol = 
        symbol_of_name(function_expression(exp));
      const processed_args = map(query_syntax_process, args(exp));
      return function_symbol === "pair"
        ? pair(head(processed_args), head(tail(processed_args)))
        : function_symbol === "list"
        ? processed_args
        : function_symbol === "javascript_value"
        ? pair(function_symbol,
               list(javascript_value_process(head(args(exp)))))
        : pair(function_symbol, processed_args);
    } else if (is_name(exp)) {
      return list("?", symbol_of_name(exp));
    } else {
      return exp;
    }
}
function type(exp) {
    return is_pair(exp)
        ? head(exp)
        : error(exp, "Unknown expression in type:");
}
function contents(exp) {
    return is_pair(exp)
        ? tail(exp)
        : error(exp, "Unknown expression in contents:");
}
function assertion_to_be_added(exp) {
    return type(exp) === "assert";
}
function add_assertion_body(exp) {
    return head(contents(exp));
}
// operation_table, put and get
// from chapter 3 (section 3.3.3)
function assoc(key, records) {
    return is_null(records)
           ? undefined
           : equal(key, head(head(records)))
             ? head(records)
             : assoc(key, tail(records));
}
function make_table() {
    const local_table = list("*table*");
    function lookup(key_1, key_2) {
        const subtable = assoc(key_1, tail(local_table));
        if (subtable === undefined) {
            return undefined;
        } else {
            const record = assoc(key_2, tail(subtable));
            if (record === undefined) {
                return undefined;
            } else {
                return tail(record);
            }
        }
    }
    function insert(key_1, key_2, value) {
        const subtable = assoc(key_1, tail(local_table));
        if (subtable === undefined) {
            set_tail(local_table,
                     pair(list(key_1, pair(key_2, value)),
                          tail(local_table)));
        } else {
            const record = assoc(key_2, tail(subtable));
            if (record === undefined) {
      	        set_tail(subtable,
	                       pair(pair(key_2, value),
                              tail(subtable)));
	    } else {
                set_tail(record, value);
            }
        }
    }
    function dispatch(m) {
        return m === "lookup"
               ? lookup
               : m === "insert"
                 ? insert
                 : "undefined operation -- table";
    }
    return dispatch;
}
const operation_table = make_table();
const get = operation_table("lookup");
const put = operation_table("insert");
function make_binding(variable, value) {
    return pair(variable, value);
}
function binding_variable(binding) {
    return head(binding);
}
function binding_value(binding) {
    return tail(binding);
}
function binding_in_frame(variable, frame) {
    return assoc(variable, frame);
}
function extend(variable, value, frame) {
    return pair(make_binding(variable, value), frame);
}
function is_var(exp) {
    return is_tagged_list(exp, "?");
}
function instantiate(exp, frame, unbound_var_handler) {
    function copy(exp) {
        if (is_var(exp)) {
            const binding = binding_in_frame(exp, frame);
            return binding === undefined
                ? unbound_var_handler(exp, frame)
                : copy(binding_value(binding));
        } else if (is_pair(exp)) {
            return pair(copy(head(exp)), copy(tail(exp)));
        } else {
            return exp;
        }
    }
    return copy(exp);
}
function stream_append_delayed(s1, delayed_s2) {
    return is_null(s1)
        ? delayed_s2()
        : pair(head(s1),
               () => stream_append_delayed(stream_tail(s1),
                                           delayed_s2));
}
function interleave_delayed(s1, delayed_s2) {
    return is_null(s1)
        ? delayed_s2()
        : pair(head(s1),
               () => interleave_delayed(delayed_s2(),
                         () => stream_tail(s1)));
}
function stream_flatmap(fun, s) {
    return flatten_stream(stream_map(fun, s));
}
function flatten_stream(stream) {
    return is_null(stream)
        ? null
        : interleave_delayed(head(stream),
              () => flatten_stream(stream_tail(stream)));
}
function extend_if_consistent(variable, dat, frame) {
    const binding = binding_in_frame(variable, frame);
    return binding === undefined
        ? extend(variable, dat, frame)
        : pattern_match(binding_value(binding), dat, frame);
}
function pattern_match(pat, dat, frame) {
    return frame === "failed" 
        ? "failed"
        : equal(pat, dat) 
        ? frame   
        : is_var(pat) 
        ? extend_if_consistent(pat, dat, frame)
        : is_pair(pat) && is_pair(dat)
        ? pattern_match(tail(pat),
                        tail(dat),
                        pattern_match(head(pat),
                                      head(dat),
                                      frame))
        : "failed";
}
function singleton_stream(x) {
    return pair(x, () => null);
}
function check_an_assertion(assertion, query_pat, query_frame) {
    const match_result = pattern_match(query_pat, assertion, 
                                       query_frame);
    return match_result === "failed"
        ? null
        : singleton_stream(match_result);
}
function use_index(pat) {
    return is_string(head(pat));
}
function get_stream(key1, key2) {
    const s = get(key1, key2);
    return s === undefined ? null : s;
}
function index_key_of(pat) {
    const key = head(pat);
    return is_var(key) ? "?" : key;
}
let THE_ASSERTIONS = null;

function fetch_assertions(pattern, frame) {
    return use_index(pattern)
        ? get_indexed_assertions(pattern)
        : get_all_assertions;
}
function get_all_assertions() {
    return THE_ASSERTIONS;
}
function get_indexed_assertions(pattern) {
    return get_stream(index_key_of(pattern), "assertion-stream");
}
function find_assertions(pattern, frame) {
    return stream_flatmap(
              datum =>
                 check_an_assertion(datum, pattern, frame),
              fetch_assertions(pattern, frame));
}
let rule_counter = 0;

function new_rule_application_id() {
    rule_counter = rule_counter + 1;
    return rule_counter;
}
function make_new_variable(variable, rule_application_id) {
    return pair("?", pair(rule_application_id, tail(variable)));
}
function rename_variables_in(rule) {
    const rule_application_id = new_rule_application_id();
    function tree_walk(exp) {
        return is_var(exp) 
            ? make_new_variable(exp, rule_application_id)
            : is_pair(exp)
            ? pair(tree_walk(head(exp)),
                   tree_walk(tail(exp)))
            : exp;
    }
    return tree_walk(rule);
}
function depends_on(exp, variable, frame) {
    function tree_walk(e) {
        if (is_var(e)) {
            if (equal(variable, e)) {
                return true;
            } else {
                const b = binding_in_frame(e, frame);
                return b === undefined
                    ? false
                    : tree_walk(binding_value(b));
            }
	} else {
            return is_pair(e) 
                ? tree_walk(head(e)) || tree_walk(tail(e))
                : false;
        }
    }
    return tree_walk(exp);
}
function extend_if_possible(variable, val, frame) {
    const binding = binding_in_frame(variable, frame);
    if (binding !== undefined) {
        return unify_match(binding_value(binding), 
                            val, frame); 
    } else if (is_var(val)) {                      // ***
        const binding = binding_in_frame(val, frame);
        return binding !== undefined
            ? unify_match(variable,
                          binding_value(binding),
			  frame)
            : extend(variable, val, frame);
    } else if (depends_on(val, variable, frame)) { // ***
        return "failed";
    } else {
        return extend(variable, val, frame);
    }
}
function unify_match(p1, p2, frame) {
    return frame === "failed"
        ? "failed"
        : equal(p1, p2)
        ? frame
        : is_var(p1) 
        ? extend_if_possible(p1, p2, frame)
        : is_var(p2) 
        ? extend_if_possible(p2, p1, frame)  // ***
        : is_pair(p1) && is_pair(p2)
        ? unify_match(tail(p1),
                      tail(p2),
                      unify_match(head(p1),
                                  head(p2),
                                  frame))
        : "failed";
}
function is_rule(statement) {
    return is_tagged_list(statement, "rule");
}
function conclusion(rule) {
    return head(tail(rule));
}
function rule_body(rule) {
    return is_null(tail(tail(rule)))
        ? list("always_true")
        : head(tail(tail(rule)));
}
function apply_a_rule(rule, query_pattern, query_frame) {
    const clean_rule = rename_variables_in(rule);
    const unify_result = 
             unify_match(query_pattern,
                         conclusion(clean_rule),
                         query_frame);
    return unify_result === "failed"
        ? null
        : evaluate_query(rule_body(clean_rule),
                singleton_stream(unify_result));
}
let THE_RULES = null;

function fetch_rules(pattern, frame) {
    return use_index(pattern)
        ? get_indexed_rules(pattern)
        : get_all_rules();
}
function get_all_rules() {
    return THE_RULES;
}
function get_indexed_rules(pattern) {
    return stream_append(
              get_stream(index_key_of(pattern),
                         "rule-stream"),
              get_stream("?", "rule-stream"));
}
function apply_rules(pattern, frame) {
    return stream_flatmap(
              rule => 
                 apply_a_rule(rule, pattern, frame),
              fetch_rules(pattern, frame));
}
function simple_query(query_pattern, frame_stream) {
    return stream_flatmap(
        frame => 
            stream_append_delayed(find_assertions(query_pattern, frame),
                                  () => apply_rules(query_pattern, frame)),
        frame_stream);
}
function evaluate_query(query, frame_stream) {
    const qfun = get(type(query), "evaluate_query");
    return qfun === undefined
        ? simple_query(query, frame_stream)
        : qfun(contents(query), frame_stream);
}
function is_indexable(pat) {
    return is_string(head(pat)) || is_var(head(pat));
}
function store_assertion_in_index(assertion) {
    if (is_indexable(assertion)) {
        const key = index_key_of(assertion);
        const current_assertion_stream =
                    get_stream(key, "assertion-stream");
        put(key, "assertion-stream",
            pair(assertion, () => current_assertion_stream));
    } else {
    }
}
function store_rule_in_index(rule) {
    const pattern = conclusion(rule);
    if (is_indexable(pattern)) {
        const key = index_key_of(pattern);
        const current_rule_stream =
                    get_stream(key, "rule-stream");
        put(key, "rule-stream",
            pair(rule, () => current_rule_stream));
    } else {
    }
}
function add_rule_or_assertion(assertion) {
    return is_rule(assertion) 
        ? add_rule(assertion)
        : add_assertion(assertion);
}
function add_assertion(assertion) {
    store_assertion_in_index(assertion);
    const old_assertions = THE_ASSERTIONS;
    THE_ASSERTIONS = pair(assertion, () => old_assertions);
    return "ok";
}
function add_rule(rule) {
    store_rule_in_index(rule);
    const old_rules = THE_RULES;
    THE_RULES = pair(rule, () => old_rules);
    return "ok";
}
function is_empty_conjunction(exps) {
    return is_null(exps);
}
function first_conjunct(exps) {
    return head(exps);
}
function rest_conjuncts(exps) {
    return tail(exps);
}
function is_empty_disjunction(exps) {
    return is_null(exps);
}
function first_disjunct(exps) {
    return head(exps);
}
function rest_disjuncts(exps) {
    return tail(exps);
}
function negated_query(exps) {
    return head(exps);
}
function predicate(exps) {
    return head(exps);
}
function argmnts(exps) {
    return tail(exps);
}
function conjoin(conjuncts, frame_stream) {
    return is_empty_conjunction(conjuncts)
        ? frame_stream
        : conjoin(rest_conjuncts(conjuncts),
                  evaluate_query(first_conjunct(conjuncts),
	                frame_stream));
}
put("and", "evaluate_query", conjoin);
function disjoin(disjuncts, frame_stream) {
    return is_empty_disjunction(disjuncts)
        ? null
        : interleave_delayed(
              evaluate_query(first_disjunct(disjuncts), frame_stream),
	      () => disjoin(rest_disjuncts(disjuncts),
	                    frame_stream));
}
put("or", "evaluate_query", disjoin);
function negate(args, frame_stream) {
    return stream_flatmap(
              frame =>
	         is_null(evaluate_query(negated_query(args),
                               singleton_stream(frame)))
	         ? singleton_stream(frame)
		 : null,
	      frame_stream);
}
put("not", "evaluate_query", negate);
function execute(exp) {
    return evaluate(predicate(exp), the_global_environment);
}
function javascript_value(call, frame_stream) {
    return stream_flatmap(
              frame =>
              execute(instantiate(call, frame,
                        (v, f) =>
                        error(v, "Unknown pat var: javascript_value")))
                 ? singleton_stream(frame)
                 : null,
              frame_stream);
}
put("javascript_value", "evaluate_query", javascript_value);
const max_display = 9;
function display_stream(s) {
    function display_stream_iter(st, n) {
        if (is_null(st)) {
        } else if (n === 0) {
            display('', "...");
        } else {
            display(head(st));
            display_stream_iter(stream_tail(st), n - 1);
        }
    }
    display_stream_iter(s, max_display);
}
function always_true(ignore, frame_stream) {
    return frame_stream;
}
put("always_true", "evaluate_query", always_true);

const input_prompt = "query input:";

function query_driver_loop() {
    const input = prompt(input_prompt);
    if (is_null(input)) {
        display("--- evaluator terminated ---");
    } else {
        const q = query_syntax_process(parse(input + ";"));
        display("---- driver loop input -----");
        display(pretty_query(q));
        if (assertion_to_be_added(q)) {
            add_rule_or_assertion(add_assertion_body(q));
            display("Assertion added to data base.");
        } else {
            display("------ query results -------", "");
            display_stream(
              stream_map(
                frame =>
                  pretty_query(
		    instantiate(q, frame, (v, _) => v)),
                evaluate_query(q, singleton_stream(null))));
        }
        query_driver_loop();
    }
}
function process_query(input, verbosity) {
    const q = query_syntax_process(parse(input + ";"));
    if (verbosity !== "silent") {
        display("--- process query input  ---"); 
        display(pretty_query(q)); } else {}
    if (assertion_to_be_added(q)) {
        add_rule_or_assertion(add_assertion_body(q));
        if (verbosity !== "silent") {
            display("----- assertion added ------"); } else {}
    } else {
        display("------ query results -------");
        display_stream(
            stream_map(
                frame =>
                    pretty_query(
                        instantiate(q, frame, (v, f) => v)),
                evaluate_query(q, singleton_stream(null))));
    }
}
process_query('assert(address(list("Bitdiddle", "Ben"), list("Slumerville", "Ridge Road", 10)))', "silent");
process_query('assert(job(list("Bitdiddle", "Ben"), list("computer", "wizard")))', "silent");
process_query('assert(salary(list("Bitdiddle", "Ben"), 60000))', "silent");
process_query('assert(address(list("Hacker", "Alyssa", "P"), list("Cambridge", "Mass Ave", 78)))', "silent");
process_query('assert(job(list("Hacker", "Alyssa", "P"), list("computer", "programmer")))', "silent");
process_query('assert(salary(list("Hacker", "Alyssa", "P"), 40000))', "silent");
process_query('assert(supervisor(list("Hacker", "Alyssa", "P"), list("Bitdiddle", "Ben")))', "silent");

process_query('assert(address(list("Fect", "Cy", "D"), list("Cambridge", "Ames Street", 3)))', "silent");
process_query('assert(job(list("Fect", "Cy", "D"), list("computer", "programmer")))', "silent");
process_query('assert(salary(list("Fect", "Cy", "D"), 35000))', "silent");
process_query('assert(supervisor(list("Fect", "Cy", "D"), list("Bitdiddle", "Ben")))', "silent");

process_query('assert(address(list("Tweakit", "Lem", "E"), list("Boston", "Bay State Road", 22)))', "silent");
process_query('assert(job(list("Tweakit", "Lem", "E"), list("computer", "technician")))', "silent");
process_query('assert(salary(list("Tweakit", "Lem", "E"), 25000))', "silent");
process_query('assert(supervisor(list("Tweakit", "Lem", "E"), list("Bitdiddle", "Ben")))', "silent");
process_query('assert(address(list("Reasoner", "Louis"), list("Slumerville", "Pine Tree Road", 80)))', "silent");
process_query('assert(job(list("Reasoner", "Louis"), list("computer", "programmer", "trainee")))', "silent");
process_query('assert(salary(list("Reasoner", "Louis"), 30000))', "silent");
process_query('assert(supervisor(list("Reasoner", "Louis"), list("Hacker", "Alyssa", "P")))', "silent");
process_query('assert(supervisor(list("Bitdiddle", "Ben"), list("Warbucks", "Oliver")))', "silent");

process_query('assert(address(list("Warbucks", "Oliver"), list("Swellesley", "Top Heap Road")))', "silent");
process_query('assert(job(list("Warbucks", "Oliver"), list("administration", "big", "wheel")))', "silent");
process_query('assert(salary(list("Warbucks", "Oliver"), 150000))', "silent");
process_query('assert(address(list("Scrooge", "Eben"), list("Weston", "Shady Lane", 10)))', "silent");
process_query('assert(job(list("Scrooge", "Eben"), list("accounting", "chief", "accountant")))', "silent");
process_query('assert(salary(list("Scrooge", "Eben"), 75000))', "silent");
process_query('assert(supervisor(list("Scrooge", "Eben"), list("Warbucks", "Oliver")))', "silent");

process_query('assert(address(list("Cratchet", "Robert"), list("Allston", "N Harvard Street", 16)))', "silent");
process_query('assert(job(list("Cratchet", "Robert"), list("accounting", "scrivener")))', "silent");
process_query('assert(salary(list("Cratchet", "Robert"), 18000))', "silent");
process_query('assert(supervisor(list("Cratchet", "Robert"), list("Scrooge", "Eben")))', "silent");
process_query('assert(address(list("Aull", "DeWitt"), list("Slumerville", "Onion Square", 5)))', "silent");
process_query('assert(job(list("Aull", "DeWitt"), list("administration", "secretary")))', "silent");
process_query('assert(salary(list("Aull", "DeWitt"), 25000))', "silent");
process_query('assert(supervisor(list("Aull", "DeWitt"), list("Warbucks", "Oliver")))', "silent");
process_query('assert(can_do_job(list("computer", "wizard"), list("computer", "programmer")))', "silent");
process_query('assert(can_do_job(list("computer", "wizard"), list("computer", "technician")))', "silent");
process_query('assert(can_do_job(list("computer", "programmer"), list("computer", "programmer", "trainee")))', "silent");
process_query('assert(can_do_job(list("administration", "secretary"), list("administration", "big", "wheel")))', "silent");

function first_answer(input) {
    const q = query_syntax_process(parse(input + ";"));
    const first_frame = head(evaluate_query(q, singleton_stream(null)));
    return pretty_query(instantiate(q, first_frame, (v, f) => v));
}
first_answer('job(x, list("computer", "programmer"))');

// expected: "job(list('Fect', 'Cy', 'D'), list('computer', 'programmer'))"
