const x = amb(1, 3, 5, 7, 9);
require(x >= 4);
x;
// Press "Run" for the first solution. Type
// try again
// in the REPL on the right, for more solutions
