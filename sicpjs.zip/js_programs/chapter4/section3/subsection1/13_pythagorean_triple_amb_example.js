a_pythogorean_triple_between(5, 15);
// Press "Run" for the first solution. Type
// try_again
// in the REPL on the right, for more solutions
