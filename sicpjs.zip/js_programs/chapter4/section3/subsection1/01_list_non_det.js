// chapter=3 variant=non-det 
list(amb(1, 2, 3), amb("a", "b"));
// Press "Run" for the first solution. Type
// try_again
// in the REPL on the right, for more solutions
