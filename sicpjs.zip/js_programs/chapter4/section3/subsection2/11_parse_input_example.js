// chapter=3 variant=non-det 
let unparsed = null;
const nouns = list("noun", "student", "professor", "cat", "class");

const verbs = list("verb", "studies", "lectures", "eats", "sleeps");

const articles = list("article", "the", "a");
function parse_word(word_list) {      
    require(! is_null(unparsed));
    require(! is_null(member(head(unparsed), tail(word_list))));
    const found_word = head(unparsed);
    unparsed = tail(unparsed);
    return list(head(word_list), found_word);
}
function parse_noun_phrase() {
    return list("noun-phrase",
                parse_word(articles),
                parse_word(nouns));
}
function parse_sentence() {      
    return list("sentence",
                parse_noun_phrase(),
                parse_word(verbs));
}
function parse_input(input) {
    unparsed = input;
    const sent = parse_sentence();
    require(is_null(unparsed));
    return sent;
}
parse_input(list("the",  "cat",  "eats"));
