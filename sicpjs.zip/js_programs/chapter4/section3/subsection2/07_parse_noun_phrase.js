// chapter=3 variant=non-det 
const nouns = list("noun", "student", "professor", "cat", "class");

const verbs = list("verb", "studies", "lectures", "eats", "sleeps");

const articles = list("article", "the", "a");
let unparsed = null;
function parse_word(word_list) {      
    require(! is_null(unparsed));
    require(member(head(unparsed), tail(word_list)) !== null);
    const found_word = head(unparsed);
    unparsed = tail(unparsed);
    return list(head(word_list), found_word);
}
function parse_sentence() {      
    return list("sentence",
                parse_noun_phrase(),
                parse_word(verbs));
}
function parse_input(input) {
    unparsed = input;
    const sent = parse_sentence();
    require(is_null(unparsed));
    return sent;
}
function parse_noun_phrase() {
    return list("noun-phrase",
                parse_word(articles),
                parse_word(nouns));
}

parse_input(list("the",  "cat",  "eats"));
