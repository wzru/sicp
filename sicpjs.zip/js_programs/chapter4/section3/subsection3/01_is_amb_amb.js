function is_amb(component) {      
    return is_tagged_list(component, "application") && 
           is_name(function_expression(component)) && 
           symbol_of_name(function_expression(component)) === "amb";
}
function amb_choices(component) {
    return args(component);
}
