// functions from SICP JS 4.1.2
function is_literal(component) {
    return is_number(component)  ||
           is_string(component)  ||
           is_boolean(component) ||
           is_null(component)    ||
           is_undefined(component);
}
function literal_value(component) {    
    return component;
}
function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}
function is_name(component) {
    return is_tagged_list(component, "name");
}
function symbol_of_name(component) {
    return head(tail(component));
}
function make_assignment(string, expression) {
    return list("assignment", string, expression);
}
function is_assignment(component) {
    return is_tagged_list(component, "assignment");
}
function assignment_symbol(component) {
    return head(tail(head(tail(component))));
}
function assignment_value_expression(component) {
    return head(tail(tail(component)));
}
function is_declaration(stmt) {
    return is_tagged_list(stmt, "constant_declaration") ||
           is_tagged_list(stmt, "variable_declaration") ||
}
function declaration_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function declaration_value_expression(stmt) {
   return head(tail(tail(stmt)));
}
function is_lambda_expression(stmt) {
   return is_tagged_list(stmt, "lambda_expression");
}
function lambda_parameters(stmt) {
   return map(symbol_of_name, head(tail(stmt)));
}
function lambda_body(stmt) {
   return head(tail(tail(stmt)));
}
function is_return_statement(stmt) {
   return is_tagged_list(stmt, "return_statement");
}
function return_expression(stmt) {
   return head(tail(stmt));
}
function is_conditional(stmt) {
    return is_tagged_list(stmt, "conditional_expression") ||
           is_tagged_list(stmt, "conditional_statement");
}
function conditional_predicate(stmt) {
   return list_ref(stmt, 1);
}
function conditional_consequent(stmt) {
   return list_ref(stmt, 2);
}
function conditional_alternative(stmt) {
   return list_ref(stmt, 3);
}
function is_sequence(stmt) {
   return is_tagged_list(stmt, "sequence");
}
function make_sequence(stmts) {
   return list("sequence", stmts);
}
function sequence_statements(stmt) {   
   return head(tail(stmt));
}
function first_statement(stmts) {
   return head(stmts);
}
function rest_statements(stmts) {
   return tail(stmts);
}
function is_empty_sequence(stmts) {
   return is_null(stmts);
}
function is_last_statement(stmts) {
   return is_null(tail(stmts));
}
function is_block(stmt) {
    return is_tagged_list(stmt, "block");
}
function block_body(stmt) {
    return head(tail(stmt));
}
function is_application(stmt) {
   return is_tagged_list(stmt, "application");
}
function function_expression(stmt) {
   return head(tail(stmt));
}
function arg_expressions(stmt) {
   return head(tail(tail(stmt)));
}

function is_amb(component) {      
    return is_tagged_list(component, "application") && 
           is_name(function_expression(component)) && 
           symbol_of_name(function_expression(component)) === "amb";
}
function amb_choices(component) {
    return args(component);
}
