// functions from SICP JS 4.1.2
function is_self_evaluating(stmt) {
    return is_number(stmt)  ||
           is_string(stmt)  ||
           is_boolean(stmt) ||
           is_null(stmt)    ||
           is_undefined(stmt);
}
function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}
function is_name(stmt) {
    return is_tagged_list(stmt, "name");
}
function symbol_of_name(stmt) {
    return head(tail(stmt));
}
function is_assignment(stmt) {
   return is_tagged_list(stmt, "assignment");
}
function assignment_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function assignment_value(stmt) {
   return head(tail(tail(stmt)));
}
function is_constant_declaration(stmt) {
   return is_tagged_list(stmt, "constant_declaration");
}
function constant_declaration_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function constant_declaration_value(stmt) {
   return head(tail(tail(stmt)));
}
function is_variable_declaration(stmt) {
   return is_tagged_list(stmt, "variable_declaration");
}
function variable_declaration_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function variable_declaration_value(stmt) {
   return head(tail(tail(stmt)));
}
function is_lambda_expression(stmt) {
   return is_tagged_list(stmt, "lambda_expression");
}
function lambda_parameters(stmt) {
   return map(symbol_of_name, head(tail(stmt)));
}
function lambda_body(stmt) {
   return head(tail(tail(stmt)));
}
function is_return_statement(stmt) {
   return is_tagged_list(stmt, "return_statement");
}
function return_expression(stmt) {
   return head(tail(stmt));
}
function is_conditional_expression(stmt) {
   return is_tagged_list(stmt, 
                "conditional_expression");
}
function cond_expr_pred(stmt) {
   return list_ref(stmt, 1);
}
function cond_expr_cons(stmt) {
   return list_ref(stmt, 2);
}
function cond_expr_alt(stmt) {
   return list_ref(stmt, 3);
}
function is_sequence(stmt) {
   return is_tagged_list(stmt, "sequence");
}
function make_sequence(stmts) {
   return list("sequence", stmts);
}
function sequence_statements(stmt) {   
   return head(tail(stmt));
}
function first_statement(stmts) {
   return head(stmts);
}
function rest_statements(stmts) {
   return tail(stmts);
}
function is_empty_sequence(stmts) {
   return is_null(stmts);
}
function is_last_statement(stmts) {
   return is_null(tail(stmts));
}
function is_block(stmt) {
    return is_tagged_list(stmt, "block");
}
function make_block(stmt) {
   return list("block", stmt);
}
function block_body(stmt) {
    return head(tail(stmt));
}
function is_application(stmt) {
   return is_tagged_list(stmt, "application");
}
function function_expression(stmt) {
   return head(tail(stmt));
}
function args(stmt) {
   return head(tail(tail(stmt)));
}
function no_args(ops) {
   return is_null(ops);
}
function first_arg(ops) {
   return head(ops);
}
function rest_args(ops) {
   return tail(ops);
}

// functions from SICP JS 4.1.3
function is_true(x) {
    return x === true;
}
function make_function(parameters, body, env) {
    return list("compound_function",
                parameters, body, env);
}
function is_compound_function(f) {
    return is_tagged_list(f, "compound_function");
}
function function_parameters(f) {
    return list_ref(f, 1);
}
function function_body(f) {
    return list_ref(f, 2);
}
function function_environment(f) {
    return list_ref(f, 3);
}
function make_return_value(content) {
    return list("return_value", content);
}
function is_return_value(value) {
    return is_tagged_list(value, "return_value");
}
function return_value_content(value) {
    return head(tail(value));
}
function enclosing_environment(env) {
    return tail(env);
}
function first_frame(env) {
    return head(env);
}
function enclose_by(frame, env) {    
    return pair(frame, env);
}
const the_empty_environment = null;
function make_frame(symbols, values) {
    return pair(symbols, values);
}
function frame_symbols(frame) {    
    return head(frame);
}
function frame_values(frame) {    
    return tail(frame);
}
function extend_environment(symbols, vals, base_env) {
    return length(symbols) === length(vals)
           ? pair(make_frame(symbols, vals), base_env)
           : length(symbols) < length(vals)
             ? error("Too many arguments supplied: " + 
                     stringify(symbols) + ", " + 
                     stringify(vals))
             : error("Too few arguments supplied: " + 
                     stringify(symbols) + ", " + 
                     stringify(vals));
}
function lookup_symbol_value(symbol, env) {
    function env_loop(env) {
        function scan(symbols, vals) {
            return is_null(symbols)
                   ? env_loop(
                       enclosing_environment(env))
                   : symbol === head(symbols)
                     ? head(vals)
                     : scan(tail(symbols), tail(vals));
        }
        if (env === the_empty_environment) {
            error(symbol, "Unbound name");
        } else {
            const frame = first_frame(env);
            return scan(frame_symbols(frame),
                        frame_values(frame));
        }
    }
    return env_loop(env);
}
function assign_symbol_value(symbol, val, env) {
    function env_loop(env) {
        function scan(symbols, vals) {
            return is_null(symbols)
                ? env_loop(
                    enclosing_environment(env))
                : symbol === head(symbols)
                  ? set_head(vals, val)
                  : scan(tail(symbols), tail(vals));
        } 
        if (env === the_empty_environment) {
            error(symbol, "Unbound name -- assignment");
        } else {
            const frame = first_frame(env);
            return scan(frame_symbols(frame),
                        frame_values(frame));
        }
    }
    return env_loop(env);
}

// functions from SICP JS 4.1.4
function is_primitive_function(fun) {
   return is_tagged_list(fun, "primitive");
}
function primitive_implementation(fun) {
   return head(tail(fun));
}
const primitive_functions = list(
       list("head",    head             ),
       list("tail",    tail             ),
       list("pair",    pair             ),
       list("list",    list             ),
       list("is_null", is_null          ),
       list("display", display          ),
       list("error",   error            ),
       list("math_abs",math_abs         ),
       list("+",       (x, y) => x + y  ),
       list("-",       (x, y) => x - y  ),
       list("*",       (x, y) => x * y  ),
       list("/",       (x, y) => x / y  ),
       list("%",       (x, y) => x % y  ),
       list("===",     (x, y) => x === y),
       list("!==",     (x, y) => x !== y),
       list("<",       (x, y) => x <   y),
       list("<=",      (x, y) => x <=  y),
       list(">",       (x, y) => x >   y),
       list(">=",      (x, y) => x >=  y),
       list("!",        x     =>   !   x)
       );
const primitive_function_symbols =
        map(head, primitive_functions);
const primitive_function_objects =
        map(fun => list("primitive", head(tail(fun))),
            primitive_functions);
const primitive_constants = list(list("undefined", undefined),
                                 list("Infinity",  Infinity),
                                 list("math_PI",   math_PI),
                                 list("math_E",    math_E),
                                 list("NaN",       NaN)
                                );
const primitive_constant_symbols =
        map(f => head(f), primitive_constants);
const primitive_constant_values =
        map(f => head(tail(f)), primitive_constants);
function apply_primitive_function(fun, arg_list) {
    return apply_in_underlying_javascript(
                primitive_implementation(fun),
                arg_list);     
}
function setup_environment() {
    return extend_environment(
               append(primitive_function_symbols, 
                      primitive_constant_symbols),
               append(primitive_function_objects, 
                      primitive_constant_values),
               the_empty_environment);
}
let the_global_environment = setup_environment();

// functions from SICP JS 4.3.3
function is_amb(stmt) {      
    return is_tagged_list(stmt, "application") && 
           is_name(function_expression(stmt)) && 
           symbol_of_name(function_expression(stmt)) === "amb";
}
function amb_choices(stmt) {
    return args(stmt);
}
function analyze_self_evaluating(stmt) {
    return (env, succeed, fail) => succeed(stmt, fail);
}
function analyze_name(stmt) {
    return (env, succeed, fail) =>
           succeed(lookup_symbol_value(symbol_of_name(stmt), env),
                   fail);
}
function analyze_lambda_expression(stmt) {
    const parameters = lambda_parameters(stmt);
    const body = lambda_body(stmt);
    const bfun = analyze(body);
    return (env, succeed, fail) =>
           succeed(make_function(parameters, bfun, env),
                   fail);
}
function analyze_sequence(stmts) {
    function sequentially(a, b) {
        return (env, succeed, fail) => 
                   a(env, 
                     (a_value, fail2) =>
                        is_return_value(a_value)
                        ? succeed(a_value, fail2)
                        : b(env, succeed, fail2),
                     fail);
    }
    function loop(first_fun, rest_funs) {
        return is_null(rest_funs)
               ? first_fun
               : loop(sequentially(first_fun,
                          head(rest_funs)),
                      tail(rest_funs));
    }
    const funs = map(analyze, stmts);
    return is_null(funs) 
           ? env => undefined
           : loop(head(funs), tail(funs));
}
function analyze_variable_declaration(stmt) {
    const symbol = variable_declaration_symbol(stmt);
    const vfun = analyze(variable_declaration_value(stmt));
    return (env, succeed, fail) => 
              vfun(env,
                   (val, fail2) => {
                       assign_symbol_value(symbol, val, env);
                       return succeed(undefined, fail2);
                   },
                   fail);
}
function analyze_constant_declaration(stmt) {
    const symbol = 
        constant_declaration_symbol(stmt);
    const vfun = analyze(constant_declaration_value(stmt));
    return (env, succeed, fail) => 
              vfun(env,
                   (val, fail2) => {
                       assign_symbol_value(symbol, val, env);
                       return succeed(undefined, fail2);
                   },
                   fail);
}
function analyze_assignment(stmt) {
    const symbol = assignment_symbol(stmt);
    const vfun = analyze(assignment_value(stmt));
    return (env, succeed, fail) =>
        vfun(env,
             (val, fail2) => {              // *1*
                 const old_value = lookup_symbol_value(symbol, env);
                 assign_symbol_value(symbol, val, env);
                 return succeed(val,
                                () => {     // *2*
                                    assign_symbol_value(symbol,
                                                        old_value, 
                                                        env);
                                    return fail2();
                                });
             },
             fail);
}
function analyze_conditional_expression(stmt) {      
    const pfun = analyze(cond_expr_pred(stmt));
    const cfun = analyze(cond_expr_cons(stmt));
    const afun = analyze(cond_expr_alt(stmt));
    return (env, succeed, fail) =>
           pfun(env,
                // success continuation for evaluating 
                // the predicate to obtain pred_value
                (pred_value, fail2) =>
                    is_true(pred_value) 
                    ? cfun(env, succeed, fail2)
                    : afun(env, succeed, fail2),
                // failure continuation for evaluating 
                // the predicate		    
                fail);
}
function scan_out_declarations(stmt) {
    if (is_sequence(stmt)) {
        const stmts = sequence_statements(stmt);
        return is_empty_sequence(stmts)
            ? null
            : append(scan_out_declarations(first_statement(stmts)),
                     scan_out_declarations(make_sequence(
                                   rest_statements(stmts))));
    } else {
        return is_constant_declaration(stmt)
            ? list(constant_declaration_symbol(stmt))
            : is_variable_declaration(stmt)
              ? list(variable_declaration_symbol(stmt))
              : null;
    }
}
function list_of_unassigned(names) {
    return is_null(names)
        ? null
        : pair("*unassigned*", list_of_unassigned(tail(names)));	    
}
function analyze_block(stmt) {
    const body = block_body(stmt);
    const locals = scan_out_declarations(body);
    const unassigneds = list_of_unassigned(locals);
    const bfun = analyze(body);
    return (env, succeed, fail) =>
           bfun(extend_environment(locals, unassigneds, env),
                succeed, fail);             
}
function analyze_return_statement(stmt) {
    const rfun = analyze(return_expression(stmt));
    return (env, succeed, fail) =>
           rfun(env,
                (val, fail2) => succeed(make_return_value(val), fail2),
                fail);
}
function get_args(afuns, env, succeed, fail) {      
    return is_null(afuns)
        ? succeed(null, fail)
        : head(afuns)(env,
                      // success continuation for this afun
                      (arg, fail2) =>
                          get_args(tail(afuns),
                                   env,
                                   // success continuation for
                                   // recursive call to get_args
                                   (args, fail3) =>
                                       succeed(pair(arg, args),
                                               fail3),
                                   fail2),
                      fail);
}
function execute_application(fun, args, succeed, fail) {
    return is_primitive_function(fun)
        ? succeed(apply_primitive_function(fun, args),
                  fail)
        : is_compound_function(fun) 
        ? function_body(fun)(
              extend_environment(
                  function_parameters(fun),
                  args,
                  function_environment(fun)),
              (body_result, fail2) => 
                 succeed(is_return_value(body_result) 
                         ? return_value_content(body_result)
                         : undefined,
                         fail2),
              fail)
        : error(fun, "unknown function type -- " +
                     "execute_application");
}
function analyze_application(stmt) {
    const ffun = analyze(function_expression(stmt));
    const afuns = map(analyze, args(stmt));
    return (env, succeed, fail) =>
               ffun(env,
                    (fun, fail2) =>
                        get_args(afuns, 
                                 env,
                                 (args, fail3) =>
                                     execute_application(fun,
                                         args, succeed, fail3),
                                 fail2),
                    fail); 
}
function analyze_amb(exp) {
    const cfuns = map(analyze, amb_choices(exp));
    return (env, succeed, fail) => {
        function try_next(choices) {
            return is_null(choices)
                ? fail()
                : head(choices)(env,
                                succeed,
                                () => try_next(tail(choices)));
        }
        return try_next(cfuns);
    };
}
function analyze(stmt) {
    return is_self_evaluating(stmt)
           ? analyze_self_evaluating(stmt)
         : is_name(stmt)
           ? analyze_name(stmt)
         : is_constant_declaration(stmt)
           ? analyze_constant_declaration(stmt)
         : is_variable_declaration(stmt)
           ? analyze_variable_declaration(stmt)
         : is_assignment(stmt)
           ? analyze_assignment(stmt)
         : is_conditional_expression(stmt)
           ? analyze_conditional_expression(stmt)
         : is_lambda_expression(stmt)
           ? analyze_lambda_expression(stmt)
         : is_sequence(stmt)
           ? analyze_sequence(sequence_statements(stmt))
         : is_block(stmt)
           ? analyze_block(stmt)
         : is_return_statement(stmt)
           ? analyze_return_statement(stmt)
         : is_amb(stmt)
           ? analyze_amb(stmt)
         : is_application(stmt)
           ? analyze_application(stmt)
         : error(stmt, "Unknown syntax -- analyze");
}
function ambeval(exp, env, succeed, fail) {      
    return analyze(exp)(env, succeed, fail);
}
function first_solution(input) {
    return ambeval(parse("{ " + input + " }"),
                   the_global_environment,
                   (val, next_alternative) => val,
                   () => undefined);
}
function all_solutions(input) {
    let solutions = null;	
    function internal_loop(input, try_again) {
        if (input === "try_again") {
            try_again();
        } else {
            ambeval(parse("{ " + input + " }"),
                the_global_environment,
                // ambeval success
                (val, next_alternative) => {
                    solutions = pair(val, solutions);
                    return internal_loop("try_again", next_alternative);
                },
                // ambeval failure
                () => undefined
                );
        }
    }
    internal_loop(
               input,
               () => {
                   display("// internal error");
               });
    return reverse(solutions);
}
list_ref(list_ref(all_solutions("                                                      \
function require(p) {                                                \
    return ! p ? amb() : 'Satisfied require';                        \
}                                                                    \
function member(item, x) {                                           \
    return is_null(x)                                                \
        ? null                                                       \
        : item === head(x)                                           \
          ? x                                                        \
          : member(item, tail(x));                                   \
}                                                                    \
let unparsed = null;                                                 \
const nouns = list('noun', 'student', 'professor', 'cat', 'class');  \
const verbs = list('verb', 'studies', 'lectures', 'eats', 'sleeps'); \
const articles = list('article', 'the', 'a');                        \
function parse_word(word_list) {                                     \
    require(! is_null(unparsed));                                    \
    require(member(head(unparsed), tail(word_list)) !== null);       \
    const found_word = head(unparsed);                               \
    unparsed = tail(unparsed);                                       \
    return list(head(word_list), found_word);                        \
}                                                                    \
function parse_noun_phrase() {                                       \
    return list('noun-phrase',                                       \
                parse_word(articles),                                \
                parse_word(nouns));                                  \
}                                                                    \
function parse_sentence() {                                          \
    return list('sentence',                                          \
                parse_noun_phrase(),                                 \
                parse_word(verbs));                                  \
}                                                                    \
function parse_input(input) {                                        \
    unparsed = input;                                                \
    const sent = parse_sentence();                                   \
    require(is_null(unparsed));                                      \
    return sent;                                                     \
}                                                                    \
parse_input(list('the',  'cat',  'eats'));                           "),
                 0),
        2);

// expected: [ 'verb', [ 'eats', null ] ]
