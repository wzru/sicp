function try_me(a, b) {
    return a === 0 ? 1 : b;	
}
