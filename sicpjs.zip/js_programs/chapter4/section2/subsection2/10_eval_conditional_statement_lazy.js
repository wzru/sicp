function eval_conditional_statement(stmt, env) {	
    return is_true(actual_value(cond_stmt_pred(stmt),
                                env))
           ? evaluate(cond_stmt_cons(stmt), env)
           : evaluate(cond_stmt_alt(stmt), env);
}
