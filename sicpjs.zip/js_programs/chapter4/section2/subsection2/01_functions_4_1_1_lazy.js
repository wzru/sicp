// functions from SICP JS 4.1.1
// with modifications for lazy evaluation
// according to SICP JS 4.2.2
function evaluate(stmt, env) {
   return is_literal(stmt)
          ? literal_value(stmt)
          : is_name(stmt)
          ? lookup_symbol_value(symbol_of_name(stmt), env)
          : is_declaration(stmt)
          ? eval_declaration(stmt, env)
          : is_assignment(stmt)
          ? eval_assignment(stmt, env)
          : is_conditional(stmt)
          ? eval_conditional(stmt, env)
          : is_lambda_expression(stmt)
          ? make_function(lambda_parameters(stmt),
                          lambda_body(stmt),
                          env)
          : is_sequence(stmt)
          ? eval_sequence(sequence_statements(stmt), env)
          : is_block(stmt)
          ? eval_block(stmt, env)
          : is_return_statement(stmt)
          ? eval_return_statement(stmt, env)
          : is_application(stmt)      
          ? apply(actual_value(function_expression(stmt), env),
                  args(stmt), env)
          : error(stmt, "Unknown syntax -- evaluate");
}
function actual_value(exp, env) {
    return force_it(evaluate(exp, env));
}
function list_of_arg_values(exps, env) {	
     return map(exp => actual_value(exp, env), exps);
}

function list_of_delayed_args(exps, env) {	
     return map(exp => delay_it(exp, env), exps);
}
function apply(fun, args, env) {
   if (is_primitive_function(fun)) {
       return apply_primitive_function(
                  fun, list_of_arg_values(args, env));  // changed
   } else if (is_compound_function(fun)) {
      const body = function_body(fun);
      const symbols = function_parameters(fun);
      const result = evaluate(
                         body,
                         extend_environment(symbols, 
                             // following line changed
                             list_of_delayed_args(args, env),
                             function_environment(fun)));
      return is_return_value(result)
             ? return_value_content(result)
             : undefined;
   } else {
      error(fun, "Unknown function type -- apply");
   }
}
function eval_conditional(expr, env) {	
    return is_truthy(actual_value(conditional_predicate(expr), env))
           ? evaluate(conditional_consequent(expr), env)
           : evaluate(conditional_alternative(expr), env);
}
function eval_sequence(stmts, env) {
    if (is_empty_sequence(stmts)) {
        return undefined;
    } else if (is_last_statement(stmts)) {
            return evaluate(first_statement(stmts),env);
    } else {
        const first_stmt_value = 
            evaluate(first_statement(stmts),env);
        if (is_return_value(first_stmt_value)) {
            return first_stmt_value;
        } else {
            return eval_sequence(
                rest_statements(stmts),env);
        }
    }
}
function list_of_unassigned(names) {
    return map(_ => "*unassigned*", names);
}
function scan_out_declarations(component) {
    if (is_sequence(component)) {
        const stmts = sequence_statements(component);
        return is_empty_sequence(stmts)
               ? null
               : append(scan_out_declarations(first_statement(stmts)),
                        scan_out_declarations(
                            make_sequence(rest_statements(stmts))));
    } else {
        return is_declaration(component)
            ? list(declaration_symbol(component))
            : null;
    }
}
function eval_block(component, env) {
    const body = block_body(component);
    const locals = scan_out_declarations(body);
    const unassigneds = list_of_unassigned(locals);
    return evaluate(body, extend_environment(locals,
                                             unassigneds, 
                                             env));
}
function eval_return_statement(component, env) {
    return make_return_value(
               evaluate(return_expression(component), env));
}
function eval_assignment(component, env) {
    const value = evaluate(assignment_value_expression(component), env);
    assign_symbol_value(assignment_symbol(component), value, env);
    return value;
}
function eval_declaration(component, env) {
    is_function_declaration(component)	    
    ? evaluate(function_declaration_to_constant_declaration(component),
               env)
    : assign_symbol_value(declaration_symbol(component), 
                          evaluate(declaration_value_expression(component),
                                   env));
}
function is_evaluated_thunk(obj) {
    return is_tagged_list(obj, "evaluated_thunk");
}
function thunk_value(evaluated_thunk) {
    return head(tail(evaluated_thunk));
}
function force_it(obj) {
    if (is_thunk(obj)) {
        const result = actual_value(
                           thunk_exp(obj),
                           thunk_env(obj));
        set_head(obj, "evaluated_thunk");
        set_head(tail(obj), result);  // replace exp with its value
        set_tail(tail(obj), null);    // forget unneeded env
        return result;	
    } else if(is_evaluated_thunk(obj)) {
        return thunk_value(obj);
    } else {
        return obj;
    }
}
function delay_it(exp, env) {	
    return list("thunk", exp, env);
}
function is_thunk(obj) {    
    return is_tagged_list(obj, "thunk");
}
function thunk_exp(thunk) {
    return head(tail(thunk));
}
function thunk_env(thunk) {
    return head(tail(tail(thunk)));
}

