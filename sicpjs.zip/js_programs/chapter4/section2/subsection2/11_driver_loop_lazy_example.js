// functions from SICP JS 4.1.1
// with modifications for lazy evaluation
// according to SICP JS 4.2.2
function evaluate(stmt, env) {
   return is_literal(stmt)
          ? literal_value(stmt)
          : is_name(stmt)
          ? lookup_symbol_value(symbol_of_name(stmt), env)
          : is_declaration(stmt)
          ? eval_declaration(stmt, env)
          : is_assignment(stmt)
          ? eval_assignment(stmt, env)
          : is_conditional(stmt)
          ? eval_conditional(stmt, env)
          : is_lambda_expression(stmt)
          ? make_function(lambda_parameters(stmt),
                          lambda_body(stmt),
                          env)
          : is_sequence(stmt)
          ? eval_sequence(sequence_statements(stmt), env)
          : is_block(stmt)
          ? eval_block(stmt, env)
          : is_return_statement(stmt)
          ? eval_return_statement(stmt, env)
          : is_application(stmt)      
          ? apply(actual_value(function_expression(stmt), env),
                  args(stmt), env)
          : error(stmt, "Unknown syntax -- evaluate");
}
function actual_value(exp, env) {
    return force_it(evaluate(exp, env));
}
function list_of_arg_values(exps, env) {	
     return map(exp => actual_value(exp, env), exps);
}

function list_of_delayed_args(exps, env) {	
     return map(exp => delay_it(exp, env), exps);
}
function apply(fun, args, env) {
   if (is_primitive_function(fun)) {
       return apply_primitive_function(
                  fun, list_of_arg_values(args, env));  // changed
   } else if (is_compound_function(fun)) {
      const body = function_body(fun);
      const symbols = function_parameters(fun);
      const result = evaluate(
                         body,
                         extend_environment(symbols, 
                             // following line changed
                             list_of_delayed_args(args, env),
                             function_environment(fun)));
      return is_return_value(result)
             ? return_value_content(result)
             : undefined;
   } else {
      error(fun, "Unknown function type -- apply");
   }
}
function eval_conditional(expr, env) {	
    return is_true(actual_value(conditional_predicate(expr), env))
           ? evaluate(conditional_consequent(expr), env)
           : evaluate(conditional_alternative(expr), env);
}
function eval_sequence(stmts, env) {
    if (is_empty_sequence(stmts)) {
        return undefined;
    } else if (is_last_statement(stmts)) {
            return evaluate(first_statement(stmts),env);
    } else {
        const first_stmt_value = 
            evaluate(first_statement(stmts),env);
        if (is_return_value(first_stmt_value)) {
            return first_stmt_value;
        } else {
            return eval_sequence(
                rest_statements(stmts),env);
        }
    }
}
function list_of_unassigned(names) {
    return map(_ => "*unassigned*", names);
}
function scan_out_declarations(component) {
    if (is_sequence(component)) {
        const stmts = sequence_statements(component);
        return is_empty_sequence(stmts)
               ? null
               : append(scan_out_declarations(first_statement(stmts)),
                        scan_out_declarations(
                            make_sequence(rest_statements(stmts))));
    } else {
        return is_declaration(component)
            ? list(declaration_symbol(component))
            : null;
    }
}
function eval_block(component, env) {
    const body = block_body(component);
    const locals = scan_out_declarations(body);
    const unassigneds = list_of_unassigned(locals);
    return evaluate(body, extend_environment(locals,
                                             unassigneds, 
                                             env));
}
function eval_return_statement(component, env) {
    return make_return_value(
               evaluate(return_expression(component), env));
}
function eval_assignment(component, env) {
    const value = evaluate(assignment_value_expression(component), env);
    assign_symbol_value(assignment_symbol(component), value, env);
    return value;
}
function eval_declaration(component, env) {
    assign_symbol_value(declaration_symbol(component),
        evaluate(declaration_value_expression(component), env),
        env);
}
function is_evaluated_thunk(obj) {
    return is_tagged_list(obj, "evaluated_thunk");
}
function thunk_value(evaluated_thunk) {
    return head(tail(evaluated_thunk));
}
function force_it(obj) {
    if (is_thunk(obj)) {
        const result = actual_value(
                           thunk_exp(obj),
                           thunk_env(obj));
        set_head(obj, "evaluated_thunk");
        set_head(tail(obj), result);  // replace exp with its value
        set_tail(tail(obj), null);    // forget unneeded env
        return result;	
    } else if(is_evaluated_thunk(obj)) {
        return thunk_value(obj);
    } else {
        return obj;
    }
}
function delay_it(exp, env) {	
    return list("thunk", exp, env);
}
function is_thunk(obj) {    
    return is_tagged_list(obj, "thunk");
}
function thunk_exp(thunk) {
    return head(tail(thunk));
}
function thunk_env(thunk) {
    return head(tail(tail(thunk)));
}

// functions from SICP JS 4.1.2
function is_literal(component) {
    return is_number(component)  ||
           is_string(component)  ||
           is_boolean(component) ||
           is_null(component)    ||
           is_undefined(component);
}
function literal_value(component) {    
    return component;
}
function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}
function is_name(component) {
    return is_tagged_list(component, "name");
}
function symbol_of_name(component) {
    return head(tail(component));
}
function make_assignment(string, expression) {
    return list("assignment", string, expression);
}
function is_assignment(component) {
    return is_tagged_list(component, "assignment");
}
function assignment_symbol(component) {
    return head(tail(head(tail(component))));
}
function assignment_value_expression(component) {
    return head(tail(tail(component)));
}
function is_declaration(stmt) {
    return is_tagged_list(stmt, "constant_declaration") ||
           is_tagged_list(stmt, "variable_declaration") ||
}
function declaration_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function declaration_value_expression(stmt) {
   return head(tail(tail(stmt)));
}
function is_lambda_expression(stmt) {
   return is_tagged_list(stmt, "lambda_expression");
}
function lambda_parameters(stmt) {
   return map(symbol_of_name, head(tail(stmt)));
}
function lambda_body(stmt) {
   return head(tail(tail(stmt)));
}
function is_return_statement(stmt) {
   return is_tagged_list(stmt, "return_statement");
}
function return_expression(stmt) {
   return head(tail(stmt));
}
function is_conditional(stmt) {
    return is_tagged_list(stmt, "conditional_expression") ||
           is_tagged_list(stmt, "conditional_statement");
}
function conditional_predicate(stmt) {
   return list_ref(stmt, 1);
}
function conditional_consequent(stmt) {
   return list_ref(stmt, 2);
}
function conditional_alternative(stmt) {
   return list_ref(stmt, 3);
}
function is_sequence(stmt) {
   return is_tagged_list(stmt, "sequence");
}
function make_sequence(stmts) {
   return list("sequence", stmts);
}
function sequence_statements(stmt) {   
   return head(tail(stmt));
}
function first_statement(stmts) {
   return head(stmts);
}
function rest_statements(stmts) {
   return tail(stmts);
}
function is_empty_sequence(stmts) {
   return is_null(stmts);
}
function is_last_statement(stmts) {
   return is_null(tail(stmts));
}
function is_block(stmt) {
    return is_tagged_list(stmt, "block");
}
function block_body(stmt) {
    return head(tail(stmt));
}
function is_application(stmt) {
   return is_tagged_list(stmt, "application");
}
function function_expression(stmt) {
   return head(tail(stmt));
}
function arg_expressions(stmt) {
   return head(tail(tail(stmt)));
}

// functions from SICP JS 4.1.3
function is_true(x) {
    return is_boolean(x) 
           ? x === true 
           : error(x, "boolean expected, received:");
}
function make_function(parameters, body, env) {
    return list("compound_function",
                parameters, body, env);
}
function is_compound_function(f) {
    return is_tagged_list(f, "compound_function");
}
function function_parameters(f) {
    return list_ref(f, 1);
}
function function_body(f) {
    return list_ref(f, 2);
}
function function_environment(f) {
    return list_ref(f, 3);
}
function make_return_value(content) {
    return list("return_value", content);
}
function is_return_value(value) {
    return is_tagged_list(value, "return_value");
}
function return_value_content(value) {
    return head(tail(value));
}
function enclosing_environment(env) {
    return tail(env);
}
function first_frame(env) {
    return head(env);
}
function enclose_by(frame, env) {    
    return pair(frame, env);
}
const the_empty_environment = null;
function make_frame(symbols, values) {
    return pair(symbols, values);
}
function frame_symbols(frame) {    
    return head(frame);
}
function frame_values(frame) {    
    return tail(frame);
}
function extend_environment(symbols, vals, base_env) {
    return length(symbols) === length(vals)
           ? pair(make_frame(symbols, vals), base_env)
           : length(symbols) < length(vals)
             ? error("Too many arguments supplied: " + 
                     stringify(symbols) + ", " + 
                     stringify(vals))
             : error("Too few arguments supplied: " + 
                     stringify(symbols) + ", " + 
                     stringify(vals));
}
function lookup_symbol_value(symbol, env) {
    function env_loop(env) {
        function scan(symbols, vals) {
            return is_null(symbols)
                   ? env_loop(
                       enclosing_environment(env))
                   : symbol === head(symbols)
                     ? head(vals)
                     : scan(tail(symbols), tail(vals));
        }
        if (env === the_empty_environment) {
            error(symbol, "Unbound name");
        } else {
            const frame = first_frame(env);
            return scan(frame_symbols(frame),
                        frame_values(frame));
        }
    }
    return env_loop(env);
}
function assign_symbol_value(symbol, val, env) {
    function env_loop(env) {
        function scan(symbols, vals) {
            return is_null(symbols)
                ? env_loop(
                    enclosing_environment(env))
                : symbol === head(symbols)
                  ? set_head(vals, val)
                  : scan(tail(symbols), tail(vals));
        } 
        if (env === the_empty_environment) {
            error(symbol, "Unbound name -- assignment");
        } else {
            const frame = first_frame(env);
            return scan(frame_symbols(frame),
                        frame_values(frame));
        }
    }
    return env_loop(env);
}

// functions from SICP JS 4.1.4
function is_primitive_function(fun) {
   return is_tagged_list(fun, "primitive");
}
function primitive_implementation(fun) {
   return head(tail(fun));
}
const primitive_functions = list(
       list("head",    head             ),
       list("tail",    tail             ),
       list("pair",    pair             ),
       list("list",    list             ),
       list("is_null", is_null          ),
       list("display", display          ),
       list("error",   error            ),
       list("math_abs",math_abs         ),
       list("+",       (x, y) => x + y  ),
       list("-",       (x, y) => x - y  ),
       list("*",       (x, y) => x * y  ),
       list("/",       (x, y) => x / y  ),
       list("%",       (x, y) => x % y  ),
       list("===",     (x, y) => x === y),
       list("!==",     (x, y) => x !== y),
       list("<",       (x, y) => x <   y),
       list("<=",      (x, y) => x <=  y),
       list(">",       (x, y) => x >   y),
       list(">=",      (x, y) => x >=  y),
       list("!",        x     =>   !   x)
       );
const primitive_function_symbols =
        map(head, primitive_functions);
const primitive_function_objects =
        map(fun => list("primitive", head(tail(fun))),
            primitive_functions);
const primitive_constants = list(list("undefined", undefined),
                                 list("Infinity",  Infinity),
                                 list("math_PI",   math_PI),
                                 list("math_E",    math_E),
                                 list("NaN",       NaN)
                                );
const primitive_constant_symbols =
        map(f => head(f), primitive_constants);
const primitive_constant_values =
        map(f => head(tail(f)), primitive_constants);
function apply_primitive_function(fun, arglist) {
    return apply_in_underlying_javascript(
                primitive_implementation(fun),
                arglist);     
}
function setup_environment() {
    return extend_environment(
               append(primitive_function_symbols, 
                      primitive_constant_symbols),
               append(primitive_function_objects, 
                      primitive_constant_values),
               the_empty_environment);
}
let the_global_environment = setup_environment();

function user_print(prompt_string, object) {
   function to_string(object) {	
       return is_compound_function(object)
              ? "<compound-function>"
              : is_primitive_function(object)
	      ? "<primitive-function>"
	      : is_pair(object)
	      ? "[" + to_string(head(object)) + ", "
	            + to_string(tail(object)) + "]"
	      : stringify(object);
    }
    display("----------------------------",
            prompt_string + "\n" + to_string(object) + "\n");
}
function user_read(prompt_string) {
    return prompt(prompt_string);
}
const input_prompt = "L-evaluate input: ";
const output_prompt = "L-evaluate value: ";

function driver_loop(env) {
    const input = user_read(input_prompt);
    if (input === null) {
        display("--- evaluator terminated ---", "");
    } else {
        display("----------------------------",
                input_prompt + "\n" + input + "\n");
        const program = parse(input);
        const locals = scan_out_declarations(program);
        const unassigneds = list_of_unassigned(locals);
        const program_env = extend_environment(locals, unassigneds, env);
        const output = actual_value(program, program_env);
        user_print(output_prompt, output);
        driver_loop(program_env);
    }
}
driver_loop(the_global_environment);

// L-evaluate input:
// function try_me(a, b) { return a === 0 ? 1 : b; }
// L-evaluate value:
// undefined

// L-evaluate input:
// try_me(0, head(null));
// L-evaluate value:
// 1
