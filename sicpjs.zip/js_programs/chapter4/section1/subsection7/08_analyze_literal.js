function analyze_literal(component) {      
    return env => literal_value(component);
}

// null is the empty environment (not used here)	
analyze_literal(parse("true;"))(null);

// expected: true
