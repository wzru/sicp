// null is the empty environment (not used here)	
analyze_self_evaluating(parse("true;"))(null);
