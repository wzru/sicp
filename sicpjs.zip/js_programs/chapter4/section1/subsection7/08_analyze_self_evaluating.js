function analyze_self_evaluating(stmt) {      
    return env => stmt;
}

// null is the empty environment (not used here)	
analyze_self_evaluating(parse("true;"))(null);

// expected: true
