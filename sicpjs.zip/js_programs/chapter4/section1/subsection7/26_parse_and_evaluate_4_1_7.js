function parse_and_evaluate(input) {
    const program = parse(input);
    const locals = scan_out_declarations(program);
    const unassigneds = list_of_unassigned(locals);
    const program_env = extend_environment(locals, unassigneds,
                                       the_global_environment);
    return evaluate(program, program_env);
}
