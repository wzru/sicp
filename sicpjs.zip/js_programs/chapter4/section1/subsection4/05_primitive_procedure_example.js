const my_primitive_plus =
    make_primitive_function( (x, y) => x + y );	    
display(is_primitive_function(my_primitive_plus));
display(primitive_implementation(my_primitive_plus));
