function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}
function make_primitive_function(impl) {
    return list("primitive", impl);
}
function is_primitive_function(fun) {
   return is_tagged_list(fun, "primitive");
}
function primitive_implementation(fun) {
   return list_ref(fun, 1);
}
const my_primitive_plus =
    make_primitive_function( (x, y) => x + y );	    
display(is_primitive_function(my_primitive_plus));
display(primitive_implementation(my_primitive_plus));
function apply_primitive_function(fun, argument_list) {
    return apply_in_underlying_javascript(
                primitive_implementation(fun),
                argument_list);     
}

apply_primitive_function(my_primitive_plus, list(1, 2));
