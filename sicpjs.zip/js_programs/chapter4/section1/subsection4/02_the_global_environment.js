const the_global_environment = setup_environment();
