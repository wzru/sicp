length(primitive_constants);
