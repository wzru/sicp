is_truthy(1); // should return false because only true is truthy
