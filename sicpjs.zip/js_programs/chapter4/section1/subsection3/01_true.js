function is_true(x) {
    return x === true;
}

is_true(1); // should return false because only true is true
