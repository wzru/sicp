function enclosing_environment(env) {
    return tail(env);
}
function first_frame(env) {
    return head(env);
}
function enclose_by(frame, env) {    
    return pair(frame, env);
}
const the_empty_environment = null;
function is_empty_environment(env) {
    return is_null(env);
}
const my_function = 
    make_compound_function(
        list("x", "y"),
        list("return_statement", parse("x + y;")),
        the_empty_environment);
display(is_compound_function(my_function));
display(function_parameters(my_function));
display(function_body(my_function));
display(function_environment(my_function));
