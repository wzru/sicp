const unassigned = () => null;
function list_of_unassigned(names) {
    return is_null(names)
        ? null
        : pair(unassigned, list_of_unassigned(tail(names)));	    
}
