// functions from SICP JS 4.1.1
function evaluate(stmt, env) {
   return is_self_evaluating(stmt)
          ?  stmt
          : is_name(stmt)
          ? lookup_symbol_value(symbol_of_name(stmt), env)
          : is_constant_declaration(stmt)
          ? eval_constant_declaration(stmt, env)
          : is_variable_declaration(stmt)
          ? eval_variable_declaration(stmt, env)
          : is_assignment(stmt)
          ? eval_assignment(stmt, env)
          : is_conditional_expression(stmt)
          ? eval_conditional_expression(stmt, env)
          : is_lambda(stmt)
          ? make_function(lambda_parameters(stmt),
                          lambda_body(stmt),
                          env)
          : is_sequence(stmt)
          ? eval_sequence(sequence_statements(stmt), env)
          : is_block(stmt)
          ? eval_block(stmt, env)
          : is_return(stmt)
          ? eval_return(stmt, env)
          : is_application(stmt)
          ? apply(evaluate(function_expression(stmt), env),
                  list_of_values(args(stmt), env))
          : error(stmt, "Unknown syntax -- evaluate");
}
function apply(fun, args) {
   if (is_primitive_function(fun)) {
      return apply_primitive_function(fun, args);
   } else if (is_compound_function(fun)) {
      const result = evaluate(function_body(fun),
                         extend_environment(
                             function_parameters(fun),
                             args,
                             function_environment(fun)));
      return is_return_value(result)
             ? return_value_content(result)
             : undefined;
   } else {
      error(fun, "Unknown function type -- apply");
   }
}
function list_of_values(exps, env) {
     return no_args(exps)
         ? null
         : pair(evaluate(first_arg(exps), env),
                list_of_values(rest_args(exps), env));
}
function eval_conditional_expression(stmt, env) {
    return is_true(evaluate(cond_expr_pred(stmt), env))
           ? evaluate(cond_expr_cons(stmt), env)
           : evaluate(cond_expr_alt(stmt), env);
}
const unassigned = () => null;
function list_of_unassigned(names) {
    return is_null(names)
        ? null
        : pair(unassigned, list_of_unassigned(tail(names)));	    
}
function scan_out_declarations(stmt) {
    if (is_sequence(stmt)) {
        const stmts = sequence_statements(stmt);
        return is_empty_sequence(stmts)
            ? null
            : append(scan_out_declarations(first_statement(stmts)),
                     scan_out_declarations(make_sequence(
                                   rest_statements(stmts))));
    } else {
       return is_constant_declaration(stmt)
              ? list(constant_declaration_symbol(stmt))
              : is_variable_declaration(stmt)
                ? list(variable_declaration_symbol(stmt))
                : null;
    }
}
function eval_block(stmt, env) {
    const body = block_body(stmt);
    const locals = scan_out_declarations(body);
    const unassigneds = list_of_unassigned(locals);
    return evaluate(body,
                extend_environment(locals, unassigneds, env));
}
function eval_return(stmt, env) {
    return make_return_value(
               evaluate(return_expression(stmt),
                        env));
}
function eval_assignment(stmt, env) {
    const value = evaluate(assignment_value(stmt), env);
    assign_symbol_value(assignment_symbol(stmt), value, env);
    return value;
}
function eval_variable_declaration(stmt, env) {
    assign_symbol_value(variable_declaration_symbol(stmt),
        evaluate(variable_declaration_value(stmt), env),
        env);
}   
function eval_constant_declaration(stmt, env) {
    assign_symbol_value(constant_declaration_symbol(stmt),
        evaluate(constant_declaration_value(stmt), env),
        env);
}

// functions from SICP JS 4.1.2
function is_self_evaluating(stmt) {
    return is_number(stmt)  ||
           is_string(stmt)  ||
           is_boolean(stmt) ||
           is_null(stmt);
}
function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}
function is_name(stmt) {
    return is_tagged_list(stmt, "name");
}
function symbol_of_name(stmt) {
    return head(tail(stmt));
}
function is_assignment(stmt) {
   return is_tagged_list(stmt, "assignment");
}
function assignment_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function assignment_value(stmt) {
   return head(tail(tail(stmt)));
}
function is_constant_declaration(stmt) {
   return is_tagged_list(stmt, "constant_declaration");
}
function constant_declaration_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function constant_declaration_value(stmt) {
   return head(tail(tail(stmt)));
}
function is_variable_declaration(stmt) {
   return is_tagged_list(stmt, "variable_declaration");
}
function variable_declaration_symbol(stmt) {
   return head(tail(head(tail(stmt))));
}
function variable_declaration_value(stmt) {
   return head(tail(tail(stmt)));
}
// FIXME: replace "function_definition" with "lambda"
// after this issue is handled:
// https://github.com/source-academy/js-slang/issues/634
// FIXME: remove the block from lambda_body once the
// parser wraps the body in a block whenever needed.
function is_lambda(stmt) {
   return is_tagged_list(stmt, "function_definition");
}
function lambda_parameters(stmt) {
   return map(symbol_of_name, head(tail(stmt)));
}
function lambda_body(stmt) {
   return make_block(head(tail(tail(stmt))));
}
function is_return(stmt) {
   return is_tagged_list(stmt, "return_statement");
}
function return_expression(stmt) {
   return head(tail(stmt));
}
function is_conditional_expression(stmt) {
   return is_tagged_list(stmt, 
                "conditional_expression");
}
function cond_expr_pred(stmt) {
   return list_ref(stmt, 1);
}
function cond_expr_cons(stmt) {
   return list_ref(stmt, 2);
}
function cond_expr_alt(stmt) {
   return list_ref(stmt, 3);
}
function is_sequence(stmt) {
   return is_tagged_list(stmt, "sequence");
}
function make_sequence(stmts) {
   return list("sequence", stmts);
}
function sequence_statements(stmt) {   
   return head(tail(stmt));
}
function first_statement(stmts) {
   return head(stmts);
}
function rest_statements(stmts) {
   return tail(stmts);
}
function is_empty_sequence(stmts) {
   return is_null(stmts);
}
function is_last_statement(stmts) {
   return is_null(tail(stmts));
}
function is_block(stmt) {
    return is_tagged_list(stmt, "block");
}
function make_block(stmt) {
   return list("block", stmt);
}
function block_body(stmt) {
    return head(tail(stmt));
}
function is_application(stmt) {
   return is_tagged_list(stmt, "application");
}
function function_expression(stmt) {
   return head(tail(stmt));
}
function args(stmt) {
   return head(tail(tail(stmt)));
}
function no_args(ops) {
   return is_null(ops);
}
function first_arg(ops) {
   return head(ops);
}
function rest_args(ops) {
   return tail(ops);
}

// functions from SICP JS 4.1.3
function is_true(x) {
    return x === true;
}
function make_function(parameters, body, env) {
    return list("compound_function",
                parameters, body, env);
}
function is_compound_function(f) {
    return is_tagged_list(f, "compound_function");
}
function function_parameters(f) {
    return list_ref(f, 1);
}
function function_body(f) {
    return list_ref(f, 2);
}
function function_environment(f) {
    return list_ref(f, 3);
}
function make_return_value(content) {
    return list("return_value", content);
}
function is_return_value(value) {
    return is_tagged_list(value, "return_value");
}
function return_value_content(value) {
    return head(tail(value));
}
function enclosing_environment(env) {
    return tail(env);
}
function first_frame(env) {
    return head(env);
}
function enclose_by(frame, env) {    
    return pair(frame, env);
}
const the_empty_environment = null;
function make_frame(symbols, values) {
    return pair(symbols, values);
}
function frame_symbols(frame) {    
    return head(frame);
}
function frame_values(frame) {    
    return tail(frame);
}
function extend_environment(symbols, vals, base_env) {
    return length(symbols) === length(vals)
           ? pair(make_frame(symbols, vals), base_env)
           : length(symbols) < length(vals)
             ? error("Too many arguments supplied: " + 
                     stringify(symbols) + ", " + 
                     stringify(vals))
             : error("Too few arguments supplied: " + 
                     stringify(symbols) + ", " + 
                     stringify(vals));
}
function lookup_symbol_value(symbol, env) {
    function env_loop(env) {
        function scan(symbols, vals) {
            return is_null(symbols)
                   ? env_loop(
                       enclosing_environment(env))
                   : symbol === head(symbols)
                     ? head(vals)
                     : scan(tail(symbols), tail(vals));
        }
        if (env === the_empty_environment) {
            error(symbol, "Unbound name");
        } else {
            const frame = first_frame(env);
            return scan(frame_symbols(frame),
                        frame_values(frame));
        }
    }
    return env_loop(env);
}
function assign_symbol_value(symbol, val, env) {
    function env_loop(env) {
        function scan(symbols, vals) {
            return is_null(symbols)
                ? env_loop(
                    enclosing_environment(env))
                : symbol === head(symbols)
                  ? set_head(vals, val)
                  : scan(tail(symbols), tail(vals));
        } 
        if (env === the_empty_environment) {
            error(symbol, "Unbound name -- assignment");
        } else {
            const frame = first_frame(env);
            return scan(frame_symbols(frame),
                        frame_values(frame));
        }
    }
    return env_loop(env);
}

// functions from SICP JS 4.1.4
function is_primitive_function(fun) {
   return is_tagged_list(fun, "primitive");
}
function primitive_implementation(fun) {
   return head(tail(fun));
}
const primitive_functions = list(
       list("head",    head             ),
       list("tail",    tail             ),
       list("pair",    pair             ),
       list("list",    list             ),
       list("is_null", is_null          ),
       list("display", display          ),
       list("error",   error            ),
       list("math_abs",math_abs         ),
       list("+",       (x, y) => x + y  ),
       list("-",       (x, y) => x - y  ),
       list("*",       (x, y) => x * y  ),
       list("/",       (x, y) => x / y  ),
       list("%",       (x, y) => x % y  ),
       list("===",     (x, y) => x === y),
       list("!==",     (x, y) => x !== y),
       list("<",       (x, y) => x <   y),
       list("<=",      (x, y) => x <=  y),
       list(">",       (x, y) => x >   y),
       list(">=",      (x, y) => x >=  y),
       list("!",        x     =>   !   x)
       );
const primitive_function_symbols =
        map(head, primitive_functions);
const primitive_function_objects =
        map(fun => list("primitive", head(tail(fun))),
            primitive_functions);
const primitive_constants = list(list("undefined", undefined),
                                 list("Infinity",  Infinity),
                                 list("math_PI",   math_PI),
                                 list("math_E",    math_E),
                                 list("NaN",       NaN)
                                );
const primitive_constant_symbols =
        map(f => head(f), primitive_constants);
const primitive_constant_values =
        map(f => head(tail(f)), primitive_constants);
function apply_primitive_function(fun, arg_list) {
    return apply_in_underlying_javascript(
                primitive_implementation(fun),
                arg_list);     
}
function setup_environment() {
    return extend_environment(
               append(primitive_function_symbols, 
                      primitive_constant_symbols),
               append(primitive_function_objects, 
                      primitive_constant_values),
               the_empty_environment);
}
const the_global_environment = setup_environment();

function eval_sequence(stmts, env) {
    if (is_empty_sequence(stmts)) {
        return undefined;
    } else if (is_last_statement(stmts)) {
            return evaluate(first_statement(stmts),env);
    } else {
        const first_stmt_value = 
            evaluate(first_statement(stmts),env);
        if (is_return_value(first_stmt_value)) {
            return first_stmt_value;
        } else {
            return eval_sequence(
                rest_statements(stmts),env);
        }
    }
}

const my_sequence = head(tail(parse("1; true; 3;")));
eval_sequence(my_sequence, the_empty_environment);

// expected: 3
