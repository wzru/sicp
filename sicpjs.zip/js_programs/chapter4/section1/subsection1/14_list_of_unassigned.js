function list_of_unassigned(names) {
    return map(name => "*unassigned*", names);
}
