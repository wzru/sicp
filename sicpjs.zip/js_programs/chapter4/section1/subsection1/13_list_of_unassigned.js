function list_of_unassigned(names) {
    return map(ignore => "*unassigned*", names);
}
