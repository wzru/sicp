function list_of_unassigned(names) {
    return map(_ => "*unassigned*", names);
}
