// functions from chapter 4, section 1.1
