// functions from SICP JS 4.1.1
function evaluate(stmt, env) {
   return is_self_evaluating(stmt)
          ?  stmt
          : is_name(stmt)
          ? lookup_symbol_value(symbol_of_name(stmt), env)
          : is_constant_declaration(stmt)
          ? eval_constant_declaration(stmt, env)
          : is_variable_declaration(stmt)
          ? eval_variable_declaration(stmt, env)
          : is_assignment(stmt)
          ? eval_assignment(stmt, env)
          : is_conditional_expression(stmt)
          ? eval_conditional_expression(stmt, env)
          : is_lambda_expression(stmt)
          ? make_function(lambda_parameters(stmt),
                          lambda_body(stmt),
                          env)
          : is_sequence(stmt)
          ? eval_sequence(sequence_statements(stmt), env)
          : is_block(stmt)
          ? eval_block(stmt, env)
          : is_return(stmt)
          ? eval_return(stmt, env)
          : is_application(stmt)
          ? apply(evaluate(function_expression(stmt), env),
                  list_of_values(args(stmt), env))
          : error(stmt, "Unknown syntax -- evaluate");
}
function apply(fun, args) {
   if (is_primitive_function(fun)) {
      return apply_primitive_function(fun, args);
   } else if (is_compound_function(fun)) {
      const result = evaluate(function_body(fun),
                         extend_environment(
                             function_parameters(fun),
                             args,
                             function_environment(fun)));
      return is_return_value(result)
             ? return_value_content(result)
             : undefined;
   } else {
      error(fun, "Unknown function type -- apply");
   }
}
function list_of_values(exps, env) {
     return no_args(exps)
         ? null
         : pair(evaluate(first_arg(exps), env),
                list_of_values(rest_args(exps), env));
}
function eval_conditional_expression(stmt, env) {
    return is_true(evaluate(cond_expr_pred(stmt), env))
           ? evaluate(cond_expr_cons(stmt), env)
           : evaluate(cond_expr_alt(stmt), env);
}
function eval_sequence(stmts, env) {
    if (is_empty_sequence(stmts)) {
        return undefined;
    } else if (is_last_statement(stmts)) {
            return evaluate(first_statement(stmts),env);
    } else {
        const first_stmt_value = 
            evaluate(first_statement(stmts),env);
        if (is_return_value(first_stmt_value)) {
            return first_stmt_value;
        } else {
            return eval_sequence(
                rest_statements(stmts),env);
        }
    }
}
function list_of_unassigned(names) {
    return is_null(names)
        ? null
        : pair("*unassigned*", list_of_unassigned(tail(names)));	    
}
function scan_out_declarations(stmt) {
    if (is_sequence(stmt)) {
        const stmts = sequence_statements(stmt);
        return is_empty_sequence(stmts)
            ? null
            : append(scan_out_declarations(first_statement(stmts)),
                     scan_out_declarations(make_sequence(
                                   rest_statements(stmts))));
    } else {
        return is_constant_declaration(stmt)
            ? list(constant_declaration_symbol(stmt))
            : is_variable_declaration(stmt)
              ? list(variable_declaration_symbol(stmt))
              : null;
    }
}
function eval_block(stmt, env) {
    const body = block_body(stmt);
    const locals = scan_out_declarations(body);
    const unassigneds = list_of_unassigned(locals);
    return evaluate(body,
                extend_environment(locals, unassigneds, env));
}
function eval_return(stmt, env) {
    return make_return_value(
               evaluate(return_expression(stmt),
                        env));
}
function eval_assignment(stmt, env) {
    const value = evaluate(assignment_value(stmt), env);
    assign_symbol_value(assignment_symbol(stmt), value, env);
    return value;
}
function eval_variable_declaration(stmt, env) {
    assign_symbol_value(variable_declaration_symbol(stmt),
        evaluate(variable_declaration_value(stmt), env),
        env);
}   
function eval_constant_declaration(stmt, env) {
    assign_symbol_value(constant_declaration_symbol(stmt),
        evaluate(constant_declaration_value(stmt), env),
        env);
}

