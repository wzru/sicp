const my_application = parse("math_pow(3, 4);");
display(is_application(my_application));
display(operator(my_application));
const my_operands = operands(my_application);
display(no_operands(my_operands));
display(first_operand(my_operands));
display(rest_operands(my_operands));
