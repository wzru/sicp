const my_cond_expr = 
    parse("true ? 1 : 2;");
is_conditional_expression(my_cond_expr);
cond_expr_pred(my_cond_expr);
cond_expr_cons(my_cond_expr);
cond_expr_alt(my_cond_expr);
