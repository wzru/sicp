function is_tagged_list(component, the_tag) {
    return is_pair(component) && head(component) === the_tag;
}
function is_sequential_composition(component) {		
    return is_tagged_list(component, "sequential_composition");
}
function first_statement(component) {
   return head(tail(component));
}
function second_statement(component) {
   return head(tail(tail(component)));
}

// expected: [ true, [ 45, null ] ]
