1; { if (true) { } else { 2; } }
