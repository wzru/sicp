literal_value(parse("null;"));
function literal_value(component) {    
    return head(tail(component));
}

// expected: true
