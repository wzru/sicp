literal_value(parse("null;"));

// expected: true
