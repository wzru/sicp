const my_cond_expr = 
    parse("if (true) { 1; } else { 2; }");
display(is_conditional_expression(my_cond_expr));
display(cond_expr_pred(my_cond_expr));
display(cond_expr_cons(my_cond_expr));
display(cond_expr_alt(my_cond_expr));
