const my_sequence = parse("1; true; 45;");
display(is_sequence(my_sequence));
const my_actions = sequence_statements(my_sequence);
display(is_empty_sequence(my_actions));
display(is_last_statement(my_actions));
display(first_statement(my_actions));
display(rest_statements(my_actions));
