const my_lambda = parse("x => x;");
display(is_lambda_expression(my_lambda));
display(lambda_parameters(my_lambda));
display(lambda_body(my_lambda));
