const my_function_definition = parse("x => x;");
display(is_function_definition(my_function_definition));
display(function_definition_parameters(my_function_definition));
display(function_definition_body(my_function_definition));
