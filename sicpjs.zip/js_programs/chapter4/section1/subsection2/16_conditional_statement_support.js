function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}
function is_conditional_statement(stmt) {
   return is_tagged_list(stmt, 
                "conditional_statement");
}
function cond_stmt_pred(stmt) {
   return list_ref(stmt, 1);
}
function cond_stmt_cons(stmt) {
   return list_ref(stmt, 2);
}
function cond_stmt_alt(stmt) {
   return list_ref(stmt, 3);
}
