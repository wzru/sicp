parse("x => 1;");
