const my_application = parse("math_pow(3, 4);");
display(is_application(my_application));
display(function_expression(my_application));
const my_args = args(my_application);
display(no_args(my_args));
display(first_arg(my_args));
display(rest_args(my_args));
