const my_application = parse("math_pow(3, 4);");
display(is_application(my_application));
display(function_expressionn(my_application));
const my_args = args(my_application);
display(no_args(my_argss));
display(first_args(my_args));
display(rest_args(my_args));
