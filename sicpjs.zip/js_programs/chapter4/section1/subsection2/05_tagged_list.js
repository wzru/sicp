function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}

is_tagged_list(list("name", "x"), "name");

// expected: true
