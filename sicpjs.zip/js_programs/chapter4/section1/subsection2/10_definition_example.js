const my_declaration_statement = parse("let x = 1;");
display(is_variable_declaration(my_declaration_statement));
display(variable_declaration_symbol(my_declaration_statement));
display(variable_declaration_value(my_declaration_statement));
