parse("x => { return 1; };");
