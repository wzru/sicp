parse("const x = 1;");
