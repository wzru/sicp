function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}
function is_application(stmt) {
   return is_tagged_list(stmt, "application");
}
function function_expression(stmt) {
   return head(tail(stmt));
}
function args(stmt) {
   return head(tail(tail(stmt)));
}
function no_args(ops) {
   return is_null(ops);
}
function first_arg(ops) {
   return head(ops);
}
function rest_args(ops) {
   return tail(ops);
}

const my_application = parse("math_pow(3, 4);");
display(is_application(my_application));
display(function_expressionn(my_application));
const my_args = args(my_application);
display(no_args(my_argss));
display(first_args(my_args));
display(rest_args(my_args));
