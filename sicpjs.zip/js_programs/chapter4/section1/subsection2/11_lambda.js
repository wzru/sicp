function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}
// FIXME: replace "function_definition" with "lambda"
// after this issue is handled:
// https://github.com/source-academy/js-slang/issues/634
function is_lambda(stmt) {
   return is_tagged_list(stmt, "function_definition");
}
function lambda_parameters(stmt) {
   return map(symbol_of_name, head(tail(stmt)));
}
function lambda_body(stmt) {
   return head(tail(tail(stmt)));
}

const my_lambda = parse("x => x;");
display(is_lambda(my_lambda));
display(lambda_parameters(my_lambda));
display(lambda_body(my_lambda));
