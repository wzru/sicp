function is_tagged_list(stmt, the_tag) {
    return is_pair(stmt) && head(stmt) === the_tag;
}
function is_lambda_expression(stmt) {
   return is_tagged_list(stmt, "lambda_expression");
}
function lambda_parameters(stmt) {
   return map(symbol_of_name, head(tail(stmt)));
}
function lambda_body(stmt) {
   return head(tail(tail(stmt)));
}

const my_lambda = parse("x => x;");
display(is_lambda_expression(my_lambda));
display(lambda_parameters(my_lambda));
display(lambda_body(my_lambda));
